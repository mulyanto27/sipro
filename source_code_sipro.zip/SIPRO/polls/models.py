from django.db import models

# Create your models here.
class Polls(models.Model):
    name = models.TextField()
    count = models.PositiveIntegerField()