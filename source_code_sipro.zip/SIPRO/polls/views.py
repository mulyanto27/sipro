from polls.forms import pollsForms
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.db import connection
from django.core.mail import send_mail


def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]


def index(request):
    cursor = connection.cursor()
    cursor.execute("select * from polls_polls")
    hasil = dictfetchall(cursor)
    argument = {
        'table': hasil,
    }
    cursor.close()
    return render(request, 'tables.html', argument)


def createPolls(request):
    if request.method == 'POST':
        input = get_input_polls(request)
        cursor = connection.cursor()
        cursor.execute("insert into polls_polls(name,count) values ('" +
                       input[0] + "'," + input[1] + ")")
        cursor.close()
        return redirect('/polls/')

    form = pollsForms()
    args = {'form': form, 'request': 'create'}
    return render(request, 'form.html', args)


def updatePolls(request, id):
    cursor = connection.cursor()
    if request.method == 'POST':
        input = get_input_polls(request)
        cursor.execute(
            "update polls_polls set name = '{}', count = {} where id = {}".
            format(input[0], input[1], id))
        cursor.close()
        return redirect('/polls/')

    cursor.execute(
        "select name,count from polls_polls where id = {}".format(id))
    polls = dictfetchall(cursor)
    form = pollsForms(initial={
        'name': polls[0]['name'],
        'count': polls[0]['count'],
    })
    args = {'form': form, 'request': 'update', 'id': id}
    return render(request, 'form.html', args)


def deletePolls(request, id):
    cursor = connection.cursor()
    cursor.execute("delete from polls_polls where id =" + id)
    cursor.close()
    return redirect('/polls/')


def get_input_polls(request):
    input = request.POST
    name = input['name']
    count = input['count']
    return [name, count]


def indexHttp(request):
    send_mail("Subject", "Message", "citius.sipro@gmail.com",
              ["erlanggamuhammad01@gmail.com"], False)

    return HttpResponse("Hello, world. You're at the polls index. Email Sent!")