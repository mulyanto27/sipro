from django import forms

class pollsForms(forms.Form):
    name = forms.CharField(label='Name', max_length=100, widget=forms.TextInput(attrs={'placeholder':'*Required'}))
    count = forms.CharField(label='Count', widget=forms.NumberInput(attrs={'placeholder':'*Required'}))