from django.urls import path

from . import views

app_name = "polls"
urlpatterns = [
    path('', views.index, name='index'),
    path('http', views.indexHttp, name='indexHttp'),
    path('createPolls', views.createPolls, name='createPolls'),
    path('deletePolls/<str:id>', views.deletePolls, name='deletePolls'),
    path('updatePolls/<str:id>', views.updatePolls, name='updatePolls'),
]