from django.apps import AppConfig


class PrConfig(AppConfig):
    name = 'pr'
