from django.urls import path

from . import views

app_name = "pr"
urlpatterns = [
    path('', views.view_all_pr, name='view_all_pr'),
    path('requested/', views.view_requested_pr, name='view_requested_pr'),
    path('detail/<slug:id>/', views.get_pr_by_id, name="get_pr_by_id"),
    path('create/', views.select_category_pr, name="create_pr"),
    path('select-form-type/<slug:id_category>/', views.select_form_type, name="select_form_type"),
    path('create-pr-timebased/<slug:id_category>/', views.create_pr_timebased, name="create_pr_timebased"),
    path('create-pr-sitebased/<slug:id_category>/', views.create_pr_sitebased, name="create_pr_sitebased"),
    path('create-pr-workbased/<slug:id_category>/', views.create_pr_workbased, name="create_pr_workbased"),
    # for editing timebased PR
    path('edit-timebased/<slug:id_pr>/', views.edit_pr_timebased, name="edit_pr_timebased"),
    path('add-timebased/<slug:id_pr>/', views.add_timebased, name="add_timebased"),
    path('edit-item-timebased/<slug:id_komponen>/', views.edit_item_timebased, name="edit_item_timebased"),
    path('delete-komponen/<slug:id_komponen>/', views.delete_komponen, name="delete_komponen"),
    # for editing workbased PR
    path('edit-workbased/<slug:id_pr>/', views.edit_pr_workbased, name="edit_pr_workbased"),
    path('add-workbased/<slug:id_pr>/', views.add_workbased, name="add_workbased"),
    path('edit-item-workbased/<slug:id_item>/', views.edit_item_workbased, name="edit_item_workbased"),
    path('delete-item-workbased/<slug:id_item>/', views.delete_item_workbased, name="delete_item_workbased"),
    # for editing sitebased PR
    path('edit-sitebased/<slug:id_pr>/', views.edit_pr_sitebased, name="edit_pr_sitebased"),
    path('add-sitebased/<slug:id_pr>/', views.add_sitebased, name="add_sitebased"),
    path("edit-item-sitebased/<slug:id_item>/", views.edit_item_sitebased, name="edit_item_sitebased"),
    path("delete-item-sitebased/<slug:id_item>/", views.delete_item_sitebased, name="delete_item_sitebased"),

    path('cancel/<slug:id_pr>/', views.cancel_pr, name="cancel_pr"),
    path('create-project/', views.create_project, name="create_project"),
    path('create-area/', views.create_area, name="create_area"),

    path('<str:tab>/<str:name>', views.dashboard_pr, name='dashboard_pr'),
]