from django.shortcuts import render, redirect
from django.http.response import HttpResponse, HttpResponseForbidden, HttpResponseNotFound
from django.core.serializers import serialize
from django.http import JsonResponse
from django.contrib.auth.models import User as auth_user
from django.contrib.auth.decorators import login_required
import datetime
from main.views import handle_403_page, handle_404_page
from main.models import Purchase_Request, Purchase_Order, Category, Data_Subkontraktor, \
    Category_Data_Subkontraktor, Komponen, Timebased, User, Workbased, Item_Workbased, \
    Sitebased, Item_Sitebased, Project, Area

"""Views for getting all PR"""
def view_all_pr(request):
    list_pr = Purchase_Request.objects.all().order_by('id')
    return render(request, "list_all_pr.html", {"list_pr":list_pr})

"""Function for get related vendor data based on category"""
def get_related_vendor(id_category):
    related_vendors_data = Category_Data_Subkontraktor.objects\
        .filter(category__id = id_category, data_subkontraktor__approval_status=1)\
        .values('data_subkontraktor')
    all_appropriate_vendor = [] # list object Data_Subkontraktor which match the category
    for item in related_vendors_data:
        all_appropriate_vendor.append(Data_Subkontraktor.objects.get(id=item['data_subkontraktor']))
    return all_appropriate_vendor

"""Views for getting all PR which hasn't been processed to PO"""
def view_requested_pr(request):
    list_pr = Purchase_Request.objects.filter(status=0).order_by('id')
    arguments = {"list_pr":list_pr, "unprocessed":True}
    return render(request, "list_all_pr.html", arguments)

"""Views for creating Project"""
def create_project(request):
    if request.session.get("role_id") == 5 or  request.session.get("role_id") == 6 :
        response_data = {}
        if request.POST.get('action') == 'post':
            project_name = request.POST.get('project_name')
            new_project = Project.objects.create(name = project_name)
            response_data["new_project_id"] = new_project.id
            response_data["new_project_name"] = new_project.name
            return JsonResponse(response_data)
        return JsonResponse(response_data)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for creating Area"""
def create_area(request):
    if request.session.get("role_id") == 5 or  request.session.get("role_id") == 6:
        response_data = {}
        if request.POST.get('action') == 'post':
            area_name = request.POST.get('area_name')
            new_area = Area.objects.create(name=area_name)
            response_data["new_area_id"] = new_area.id
            response_data["new_area_name"] = new_area.name
            return JsonResponse(response_data)
        return JsonResponse(response_data)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for getting PR by id"""
def get_pr_by_id(request, id):
    selected_pr = Purchase_Request.objects.get(id=id)
    form_type = selected_pr.form_type

    if(form_type == 1):
        sitebased_info = Sitebased.objects.get(komponen__pr__id=id)
        all_rows = Item_Sitebased.objects.filter(sitebased__komponen__pr__id=id)
        arguments = {"pr":selected_pr, "sitebased_info":sitebased_info, "all_rows":all_rows}
        return render(request, "detail_pr_sitebased.html", arguments)
    elif(form_type == 2):
        workbased_info = Workbased.objects.get(komponen__pr__id=id)
        all_rows = Item_Workbased.objects.filter(workbased__komponen__pr__id=id)
        
        arguments = {"pr":selected_pr, "workbased_info":workbased_info, "all_rows":all_rows}
        return render(request, "detail_pr_workbased.html", arguments)

    elif(form_type == 3):
        all_rows = Timebased.objects.filter(komponen__pr__id = id)
        arguments = {"pr":selected_pr, "all_rows":all_rows}
        return render(request, "detail_pr_timebased.html", arguments)

    return

"""Views for selecting category PR"""
def select_category_pr(request):
    if request.session.get("role_id") == 5:
        list_category = Category.objects.all()

        if request.method == "POST":
            selected_category_id = request.POST["category"]
            if int(selected_category_id) == 1:
                return redirect("pr:create_pr_sitebased", id_category=selected_category_id)
            elif int(selected_category_id) == 2:
                return redirect("pr:create_pr_workbased", id_category=selected_category_id)
            elif int(selected_category_id) in [3,4,5,6,7]:
                return redirect("pr:create_pr_timebased", id_category=selected_category_id)
            else:
                return redirect("pr:select_form_type", id_category=selected_category_id)
        arguments = {"list_category": list_category}
        return render(request, "select_pr_category.html", arguments)
    else:
        return handle_403_page(request=request, exception=HttpResponseForbidden)

"""Views for selecting form type for Materials & Others"""
def select_form_type(request, id_category):
    if request.session.get("role_id") == 5:
        arguments = {}
        if request.method == "POST":
            form_type = request.POST.get("type")
            if int(form_type) == 1:
                return redirect("pr:create_pr_sitebased", id_category=id_category)
            elif int(form_type) == 2:
                return redirect("pr:create_pr_workbased", id_category=id_category)
            elif int(form_type) == 3:
                return redirect("pr:create_pr_timebased", id_category=id_category)
        arguments = {"id_category":id_category}
        return render(request, "select_form_type.html", arguments)
    else:
        return handle_403_page(request=request, exception=HttpResponseForbidden)

"""Function for generating no PR"""
def generateNoPR():
    seq_number = get_no_pr_sequence_number()
    now = datetime.datetime.now()
    romawi_month = month_to_romawi(now.month)
    res = "{}/PR/CSI/{}/{}".format(seq_number,romawi_month,now.year)
    return res

def get_no_pr_sequence_number():
    try:
        latest_pr_id = Purchase_Request.objects.latest('id').id
        seq_num = latest_pr_id + 1
    except Purchase_Request.DoesNotExist:
        seq_num = 1
    formatted_seq = "{:04d}".format(seq_num%9999)
    return formatted_seq

def month_to_romawi(month):
    month = int(month)
    dict_romawi = {
        1: 'I',
        2: 'II',
        3: 'III',
        4: 'IV',
        5: 'V',
        6: 'VI',
        7: 'VII',
        8: 'VIII',
        9: 'IX',
        10: 'X',
        11: 'XI',
        12: 'XII',
    }
    return dict_romawi[month]

"""Views for creating PR timebased (get form & save form)"""
def create_pr_timebased(request, id_category):
    if request.session.get("role_id") == 5:
        obj_category = Category.objects.get(id=id_category)
        arguments = {"obj_category": obj_category}
        
        ## get all vendor which has correct category
        arguments["all_vendor"] = get_related_vendor(id_category)

        ## get all projects
        all_projects = Project.objects.all().order_by('name')
        arguments["all_projects"] = all_projects

        ## get all areas
        all_areas = Area.objects.all().order_by('name')
        arguments["all_areas"] = all_areas

        if request.method == "POST":
            # append all user input to dict
            user_input = {}
            ## for PR model
            try:
                username = request.session['username']
                a_user = auth_user.objects.get(username=username)
            except:
                return redirect('/login')
            user_input["pm"] = User.objects.get(user=a_user.id)
            user_input["project"] = Project.objects.get(id=request.POST.get("project"))
            user_input["area"] = Area.objects.get(id=request.POST.get("area"))
            user_input["data_subkontraktor"] = Data_Subkontraktor.objects.get(id = request.POST.get('vendor'))
            user_input["notes"] = request.POST.get("notes")
            user_input["category"] = obj_category
            ## for Timebased model
            user_input["row_timebased"] = {
                "items": request.POST.getlist("item"),
                "item_details": request.POST.getlist("item_detail"),
                "start_dates": request.POST.getlist("start_date"),
                "end_dates": request.POST.getlist("end_date"),
                "periods": request.POST.getlist("period"),
                "quantities": request.POST.getlist("quantity")
            }

            ## add object PR to database
            new_PR = Purchase_Request(
                no_pr=generateNoPR(), project=user_input['project'], area=user_input['area'],
                pm=user_input['pm'], data_subkontraktor=user_input['data_subkontraktor'],
                notes=user_input['notes'], category=user_input['category'], form_type=3    
            )
            try:
                new_PR.save()
            except:
                arguments['errorSavingPR'] = True
                return render(request, "form_create_pr_timebased.html", arguments)

            ## add komponen and timebased object
            row_timebased = user_input["row_timebased"]
            for i in range(len(row_timebased['items'])):
                new_komponen = Komponen(pr = new_PR)
                try:
                    new_komponen.save()
                except:
                    new_PR.delete()
                    arguments['errorSavingKomponen'] = True
                    return render(request, "form_create_pr_timebased.html", arguments)

                new_row_timebased = Timebased(
                    komponen=new_komponen, item=row_timebased["items"][i], item_detail=row_timebased["item_details"][i],
                    start_date=row_timebased["start_dates"][i], end_date=row_timebased["end_dates"][i],
                    period=row_timebased["periods"][i], quantity=row_timebased["quantities"][i]
                )
                try:
                    new_row_timebased.save()
                except:
                    new_PR.delete()
                    arguments['errorSavingRowTimebased'] = True
                    return render(request, "form_create_pr_timebased.html", arguments)
            
            arguments['successCreatePR'] = True
            all_rows = Timebased.objects.filter(komponen__pr__id = new_PR.id)
            arguments["pr"] = new_PR
            arguments["all_rows"] = all_rows
            return render(request, "detail_pr_timebased.html", arguments)

        return render(request, "form_create_pr_timebased.html", arguments)
    else:
        return handle_403_page(request=request, exception=HttpResponseForbidden)

"""Views for editing PR timebased"""
def edit_pr_timebased(request, id_pr, errorAddOrder=False):
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        arguments = {"pr":selected_pr, "errorAddOrder":errorAddOrder}

        ## get all vendor which has correct category
        all_appropriate_vendor = get_related_vendor(selected_pr.category.id)
        all_appropriate_vendor.remove(Data_Subkontraktor.objects.get(id=selected_pr.data_subkontraktor.id))
        arguments["all_vendor"] = all_appropriate_vendor

        ## get all projects
        all_projects = Project.objects.exclude(id=selected_pr.project.id).order_by('name')
        arguments["all_projects"] = all_projects

        ## get all areas
        all_areas = Area.objects.exclude(id=selected_pr.area.id).order_by('name')
        arguments["all_areas"] = all_areas

        ## get all rows timebased object
        all_rows = Timebased.objects.filter(komponen__pr__id = id_pr).order_by('komponen__id')
        arguments['all_rows'] = all_rows

        if request.method == "POST":
            project = request.POST.get('project')
            area = request.POST.get('area')
            vendor = request.POST.get('vendor')
            notes = request.POST.get('notes')

            try:
                # Update PR model
                selected_pr.project = Project.objects.get(id = project)
                selected_pr.area = Area.objects.get(id = area)
                selected_pr.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
                selected_pr.notes = notes
                selected_pr.save()
                arguments["successUpdatePR"] = True
                all_rows = Timebased.objects.filter(komponen__pr__id = id_pr)
                arguments["all_rows"] = all_rows
                return render(request, "detail_pr_timebased.html", arguments)
            except:
                arguments['errorUpdatePR'] = True
        return render(request, "form_edit_pr_timebased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for deleting komponen timebased"""
def delete_komponen(request, id_komponen):
    komponen = Komponen.objects.get(id=id_komponen)
    related_pm_id = komponen.pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        response_data = {}
        if request.POST.get('action') == 'post':
            komponen.delete()
            response_data["del_status"] = "Success delete the order"
            return JsonResponse(response_data)
    else:
        return handle_403_page(request=request, exception=HttpResponseForbidden)

"""Views for adding komponen/item timebased"""
def add_timebased(request, id_pr):
    arguments = {}
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            item = request.POST.get('item')
            item_detail = request.POST.get("item_detail")
            start_date = request.POST.get("start_date")
            end_date = request.POST.get("end_date")
            period = request.POST.get("period")
            quantity = request.POST.get("quantity")

            try:
                new_komponen = Komponen.objects.create(pr=selected_pr)
            except:
                return edit_pr_timebased(request, id_pr, errorAddOrder=True)
            
            try:
                new_timebased = Timebased.objects.create(
                    komponen=new_komponen, item=item, item_detail=item_detail, start_date=start_date, 
                    end_date=end_date,period=period, quantity=quantity
                )
            except:
                new_komponen.delete()
                return edit_pr_timebased(request, id_pr, errorAddOrder=True)
            return redirect('pr:edit_pr_timebased', id_pr = id_pr)
    else:
        return handle_403_page(request=request, exception=HttpResponseForbidden)

"""Views for editing item/komponen timebased"""
def edit_item_timebased(request, id_komponen):
    timebased = Timebased.objects.get(komponen__id=id_komponen)
    related_pr = Purchase_Request.objects.get(id=timebased.komponen.pr.id)
    related_pm_id = related_pr.pm.user.id
    arguments = {"obj_timebased": timebased, "pr":related_pr}
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            item = request.POST.get('item')
            item_detail = request.POST.get("item_detail")
            start_date = request.POST.get("start_date")
            end_date = request.POST.get("end_date")
            period = request.POST.get("period")
            quantity = request.POST.get("quantity")

            timebased.item = item
            timebased.item_detail = item_detail
            timebased.start_date = start_date
            timebased.end_date = end_date
            timebased.period = period
            timebased.quantity = quantity
            try:
                timebased.save()
            except:
                arguments["errorUpdate"] = True
                return render(request, "form_edit_pr_item_timebased.html", arguments)
            return redirect("pr:edit_pr_timebased", id_pr=related_pr.id)
        return render(request,"form_edit_pr_item_timebased.html", arguments)
    else:
        return handle_403_page(request=request, exception=HttpResponseForbidden)
    

"""Views for creating PR sitebased (get form & save form)"""
def create_pr_sitebased(request, id_category):
    if request.session.get("role_id") == 5:
        obj_category = Category.objects.get(id=id_category)
        arguments = {"obj_category": obj_category}
        
        ## get all vendor which has correct category
        arguments["all_vendor"] = get_related_vendor(id_category)

        ## get all projects
        all_projects = Project.objects.all().order_by('name')
        arguments["all_projects"] = all_projects

        ## get all areas
        all_areas = Area.objects.all().order_by('name')
        arguments["all_areas"] = all_areas

        if request.method == "POST":
            # append all user input to dict
            user_input = {}
            ## for PR model
            try:
                username = request.session['username']
                a_user = auth_user.objects.get(username=username)
            except:
                return redirect('/login')
            user_input["pm"] = User.objects.get(user=a_user.id)
            user_input["project"] = Project.objects.get(id=request.POST.get("project"))
            user_input["area"] = Area.objects.get(id=request.POST.get("area"))
            user_input["data_subkontraktor"] = Data_Subkontraktor.objects.get(id = request.POST.get('vendor'))
            user_input["notes"] = request.POST.get("notes")
            user_input["category"] = obj_category

            ## for Sitebased model
            user_input["site_id"] = request.POST.get("site_id")
            user_input["site_name"] = request.POST.get("site_name")
            user_input["description"] = request.POST.get("description")

            ## for Item_Sitebased model
            user_input["sow_list"] = {
                "sows": request.POST.getlist("sow"),
                "quantities": request.POST.getlist("quantity"),
            }

            ## add obj PR to database
            new_PR = Purchase_Request(
                no_pr=generateNoPR(), project=user_input["project"], area=user_input["area"],
                pm=user_input['pm'], data_subkontraktor=user_input['data_subkontraktor'],
                notes=user_input['notes'], category=user_input['category'], form_type=1    
            )
            try:
                new_PR.save()
            except:
                arguments['errorSavingPR'] = True
                return render(request, "form_create_pr_sitebased.html", arguments)
            
            ## add komponen object
            new_komponen = Komponen(pr=new_PR)
            try:
                new_komponen.save()
            except:
                new_PR.delete()
                arguments['errorSavingKomponen'] = True
                return render(request, "form_create_pr_sitebased.html", arguments)

            ## add Sitebased object
            new_sitebased = Sitebased(komponen=new_komponen, site_id=user_input["site_id"], 
                site_name=user_input["site_name"], description=user_input['description']
            )
            try:
                new_sitebased.save()
            except:
                new_PR.delete()
                arguments['errorSavingSitebased'] = True
                return render(request, "form_create_pr_sitebased.html", arguments)

            ## add Item_Sitebased object
            row_sow_list = user_input["sow_list"]
            for index in range(len(row_sow_list["sows"])):
                new_item_sitebased = Item_Sitebased(sitebased=new_sitebased,sow=row_sow_list["sows"][index] , 
                    quantity=row_sow_list["quantities"][index]
                )
                try:
                    new_item_sitebased.save()
                except:
                    new_PR.delete()
                    arguments['errorSavingItemSitebased'] = True
                    return render(request, "form_create_pr_sitebased.html", arguments)

            arguments['successCreatePR'] = True        
            sitebased_info = Sitebased.objects.get(komponen__pr__id=new_PR.id)
            all_rows = Item_Sitebased.objects.filter(sitebased__komponen__pr__id=new_PR.id)
            arguments["pr"] = new_PR
            arguments["sitebased_info"] = sitebased_info
            arguments["all_rows"] = all_rows
            return render(request, "detail_pr_sitebased.html", arguments)

        return render(request, "form_create_pr_sitebased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for editing PR sitebased"""
def edit_pr_sitebased(request, id_pr, errorAddOrder=False):
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        arguments = {"pr":selected_pr, "errorAddOrder":errorAddOrder}

        ## get all vendor which has correct category
        all_appropriate_vendor = get_related_vendor(selected_pr.category.id)
        all_appropriate_vendor.remove(Data_Subkontraktor.objects.get(id=selected_pr.data_subkontraktor.id))
        arguments["all_vendor"] = all_appropriate_vendor

        ## get all projects
        all_projects = Project.objects.exclude(id=selected_pr.project.id).order_by('name')
        arguments["all_projects"] = all_projects

        ## get all areas
        all_areas = Area.objects.exclude(id=selected_pr.area.id).order_by('name')
        arguments["all_areas"] = all_areas

        ## get Sitebased object
        sitebased_info = Sitebased.objects.get(komponen__pr__id=id_pr)
        arguments["sitebased_info"] = sitebased_info

        ## get all orders of the Sitebased PR (Item_Sitebased)
        all_rows = Item_Sitebased.objects.filter(sitebased__komponen__pr__id=id_pr)
        arguments["all_rows"] = all_rows

        if request.method == "POST":
            ## data for PR object
            project = request.POST.get('project')
            area = request.POST.get('area')
            vendor = request.POST.get('vendor')
            notes = request.POST.get('notes')

            ## data for Sitebased object
            site_id = request.POST.get("site_id")
            site_name = request.POST.get("site_name")
            description = request.POST.get("description")

            try:
                # Update PR model
                selected_pr.project = Project.objects.get(id = project)
                selected_pr.area = Area.objects.get(id = area)
                selected_pr.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
                selected_pr.notes = notes
                selected_pr.save()

                # Update Sitebased model
                sitebased_info.site_id = site_id
                sitebased_info.site_name = site_name
                sitebased_info.description = description
                sitebased_info.save()

                arguments["successUpdatePR"] = True
                return render(request, "detail_pr_sitebased.html", arguments)
            except:
                arguments["errorUpdatePR"] = True
        return render(request, "form_edit_pr_sitebased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for adding komponen/object Sitebased"""
def add_sitebased(request, id_pr):
    arguments = {}
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    selected_sitebased = Sitebased.objects.get(komponen__pr__id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            sow = request.POST.get("sow")
            quantity = request.POST.get("quantity")

            try:
                new_item_sitebased = Item_Sitebased.objects.create(
                    sitebased=selected_sitebased, sow=sow, quantity=quantity
                )
            except:
                return edit_pr_sitebased(request, id_pr, errorAddOrder=True)
            return redirect('pr:edit_pr_sitebased', id_pr = id_pr)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for editing obj Item_Sitebased"""
def edit_item_sitebased(request, id_item):
    item_sitebased = Item_Sitebased.objects.get(id = id_item)
    related_pr = Purchase_Request.objects.get(id=item_sitebased.sitebased.komponen.pr.id)
    related_pm_id = related_pr.pm.user.id
    arguments = {
        "item_sitebased":item_sitebased, "pr":related_pr
    }
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            sow = request.POST.get("sow")
            quantity = request.POST.get("quantity")

            # updating object Item_Sitebased
            item_sitebased.sow = sow
            item_sitebased.quantity = quantity
            try:
                item_sitebased.save()
            except:
                arguments["errorUpdate"] = True
                return render(request, "form_edit_item_sitebased.html", arguments)
            return redirect("pr:edit_pr_sitebased", id_pr=related_pr.id)
        return render(request,"form_edit_item_sitebased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for deleting Item_Sitebased (SOW) Object"""
def delete_item_sitebased(request, id_item):
    response_data = {}
    item_sitebased = Item_Sitebased.objects.get(id=id_item)
    related_pm_id = item_sitebased.sitebased.komponen.pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.POST.get('action') == 'post':
            item_sitebased.delete()
            response_data["del_status"] = "Success delete the order"
            return JsonResponse(response_data)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for creating PR workbased (get form & save form)"""
def create_pr_workbased(request, id_category):
    if request.session.get("role_id") == 5:
        obj_category = Category.objects.get(id=id_category)
        arguments = {"obj_category": obj_category}
        
        ## get all vendor which has correct category
        arguments["all_vendor"] = get_related_vendor(id_category)

        ## get all projects
        all_projects = Project.objects.all().order_by('name')
        arguments["all_projects"] = all_projects

        ## get all areas
        all_areas = Area.objects.all().order_by('name')
        arguments["all_areas"] = all_areas

        if request.method == "POST":
            # append all user input to dict
            user_input = {}
            ## for PR model
            try:
                username = request.session['username']
                a_user = auth_user.objects.get(username=username)
            except:
                return redirect('/login')
            user_input["pm"] = User.objects.get(user=a_user.id)
            user_input["data_subkontraktor"] = Data_Subkontraktor.objects.get(id = request.POST.get('vendor'))
            user_input["project"] = Project.objects.get(id=request.POST.get("project"))
            user_input["area"] = Area.objects.get(id=request.POST.get("area"))
            user_input["notes"] = request.POST.get("notes")
            user_input["category"] = obj_category

            ## for Workbased model
            user_input["sow"] = request.POST.get("sow")
            user_input["description"] = request.POST.get("description")

            ## for Item_Workbased model
            user_input["site_list"] = {
                "site_ids": request.POST.getlist("site_id"),
                "site_names": request.POST.getlist("site_name"),
                "quantities": request.POST.getlist("quantity"),
            }

            ## add object PR to database
            new_PR = Purchase_Request(
                no_pr=generateNoPR(), project=user_input["project"], area=user_input["area"],
                pm=user_input['pm'], data_subkontraktor=user_input['data_subkontraktor'],
                notes=user_input['notes'], category=user_input['category'], form_type=2    
            )
            try:
                new_PR.save()
            except:
                arguments['errorSavingPR'] = True
                return render(request, "form_create_pr_workbased.html", arguments)

            ## add komponen object
            new_komponen = Komponen(pr=new_PR)
            try:
                new_komponen.save()
            except:
                new_PR.delete()
                arguments['errorSavingKomponen'] = True
                return render(request, "form_create_pr_workbased.html", arguments)
            ## add workbased object
            new_workbased = Workbased(komponen=new_komponen, sow=user_input['sow'], description=user_input['description'])
            try:
                new_workbased.save()
            except:
                new_PR.delete()
                arguments['errorSavingWorkbased'] = True
                return render(request, "form_create_pr_workbased.html", arguments)
            ## add item_workbased object
            row_site_list = user_input["site_list"]
            for index in range(len(row_site_list["site_ids"])):
                new_item_workbased = Item_Workbased(workbased=new_workbased, site_id=row_site_list["site_ids"][index],
                    site_name=row_site_list["site_names"][index], quantity=row_site_list["quantities"][index]
                )
                try:
                    new_item_workbased.save()
                except:
                    new_PR.delete()
                    arguments['errorSavingItemWorkbased'] = True
                    return render(request, "form_create_pr_workbased.html", arguments)
            arguments["successCreatePR"] = True
            arguments["pr"] = new_PR
            arguments["workbased_info"] = new_workbased
            arguments["all_rows"] = Item_Workbased.objects.filter(workbased__komponen__pr__id=new_PR.id)
            return render(request, "detail_pr_workbased.html", arguments)
        return render(request, "form_create_pr_workbased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for editing PR Workbased"""
def edit_pr_workbased(request, id_pr, errorAddingOrder=False):
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        arguments = {"pr":selected_pr, "errorAddingOrder":errorAddingOrder}

        ## get all vendor which has correct category
        all_appropriate_vendor = get_related_vendor(selected_pr.category.id)
        all_appropriate_vendor.remove(Data_Subkontraktor.objects.get(id=selected_pr.data_subkontraktor.id))
        arguments["all_vendor"] = all_appropriate_vendor

        ## get all projects
        all_projects = Project.objects.exclude(id=selected_pr.project.id).order_by('name')
        arguments["all_projects"] = all_projects

        ## get all areas
        all_areas = Area.objects.exclude(id=selected_pr.area.id).order_by('name')
        arguments["all_areas"] = all_areas

        ## get Workbased info and list order
        workbased_info = Workbased.objects.get(komponen__pr__id=id_pr)
        arguments["workbased_info"] = workbased_info
        all_rows = Item_Workbased.objects.filter(workbased__komponen__pr__id=id_pr)
        arguments["all_rows"] = all_rows

        if request.method == "POST":
            project = request.POST.get('project')
            area = request.POST.get('area')
            vendor = request.POST.get('vendor')
            sow = request.POST.get('sow')
            description = request.POST.get('description')
            notes = request.POST.get('notes')

            try:
                # Update PR model
                selected_pr.project = Project.objects.get(id = project)
                selected_pr.area = Area.objects.get(id = area)
                selected_pr.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
                selected_pr.notes = notes
                selected_pr.save()

                # Update Workbased model
                workbased_info.sow = sow
                workbased_info.description = description
                workbased_info.save()

                arguments["successUpdatePR"] = True
                workbased_info = Workbased.objects.get(komponen__pr__id=id_pr)
                all_rows = Item_Workbased.objects.filter(workbased__komponen__pr__id=id_pr)
                arguments["workbased_info"] = workbased_info
                arguments["all_rows"] = all_rows
                return render(request, "detail_pr_workbased.html", arguments)
            except:
                arguments["errorUpdatePR"] = True
        return render(request, "form_edit_pr_workbased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for adding komponen workbased/Item_Workbased object"""
def add_workbased(request, id_pr):
    arguments={}
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    selected_workbased = Workbased.objects.get(komponen__pr__id=id_pr)
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            site_id = request.POST.get('site_id')
            site_name = request.POST.get("site_name")
            quantity = request.POST.get("quantity")

            try:
                new_item_workbased = Item_Workbased.objects.create(
                    workbased=selected_workbased, site_id=site_id, site_name=site_name, quantity=quantity 
                )
            except:
                return edit_pr_workbased(request, id_pr, errorAddingOrder=True)
            return redirect('pr:edit_pr_workbased', id_pr = id_pr)
    else:
        return handle_403_page(request, HttpResponseForbidden)
    
"""Views for editing Item_Workbased"""
def edit_item_workbased(request, id_item):
    item_workbased = Item_Workbased.objects.get(id=id_item)
    related_pr = Purchase_Request.objects.get(id=item_workbased.workbased.komponen.pr.id)
    related_pm_id = related_pr.pm.user.id
    arguments = {"item_workbased": item_workbased, "pr":related_pr}
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            site_id = request.POST.get("site_id")
            site_name = request.POST.get("site_name")
            quantity = request.POST.get("quantity")

            # Edit attribute item_workbased
            item_workbased.site_id = site_id
            item_workbased.site_name = site_name
            item_workbased.quantity = quantity
            try:
                item_workbased.save()
            except:
                arguments["errorUpdate"] = True
                return render(request, "form_edit_item_workbased.html", arguments)
            return redirect("pr:edit_pr_workbased", id_pr=related_pr.id)
        return render(request,"form_edit_item_workbased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for deleting Item_Workbased"""
def delete_item_workbased(request, id_item):
    response_data = {}
    item_workbased = Item_Workbased.objects.get(id=id_item)
    related_pm_id = item_workbased.workbased.komponen.pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.POST.get('action') == 'post':
            item_workbased.delete()
            response_data["del_status"] = "Success delete the order"
            return JsonResponse(response_data)
    else:
        return handle_403_page(request, HttpResponseForbidden)

"""Views for cancelling PR"""
def cancel_pr(request, id_pr):
    selected_pr = Purchase_Request.objects.get(id=id_pr)
    related_pm_id = selected_pr.pm.user.id
    if request.session.get("role_id") == 5 and request.session.get("user_id") == related_pm_id:
        if request.method == "POST":
            selected_pr.status = 2
            arguments = {"pr":selected_pr}
            try:
                selected_pr.save()
                arguments['success'] = True
            except:
                arguments['error'] = True
            if(selected_pr.form_type == 1):
                arguments["sitebased_info"] = Sitebased.objects.get(komponen__pr__id=id_pr)
                arguments["all_rows"] = Item_Sitebased.objects.filter(sitebased__komponen__pr__id=id_pr)
                return render(request, "detail_pr_sitebased.html", arguments)
            elif(selected_pr.form_type == 2):
                workbased_info = Workbased.objects.get(komponen__pr__id=id_pr)
                all_rows = Item_Workbased.objects.filter(workbased__komponen__pr__id=id_pr)
                arguments["workbased_info"] = workbased_info
                arguments["all_rows"] = all_rows
                return render(request, "detail_pr_workbased.html", arguments)
            elif(selected_pr.form_type == 3):
                all_rows = Timebased.objects.filter(komponen__pr__id = id_pr)
                arguments['all_rows'] = all_rows
                return render(request, "detail_pr_timebased.html", arguments)
    else:
        return handle_403_page(request, HttpResponseForbidden)

'''Views for all Purchase Request based on Dashboard'''
def dashboard_pr(request, tab, name):
    if not (request.session['role_id'] == 8):
        results = {}
        if tab == 'category':
            #get all data about each PR based on its categories
            pr_per_category = Purchase_Request.objects.filter(
                category__category_name=name).order_by('no_pr')
            results['list_pr'] = pr_per_category
        elif tab == 'project':
            #get all data about each PR based on its project name
            pr_per_project = Purchase_Request.objects.filter(
                project__name=name).order_by('no_pr')
            results['list_pr'] = pr_per_project
        elif tab == 'area':
            #get all data about each PR based on its area name
            pr_per_area = Purchase_Request.objects.filter(
                area__name=name).order_by('no_pr')
            results['list_pr'] = pr_per_area
        else:
            return handle_404_page(request, HttpResponseNotFound)
        
        results['tab'] = tab.capitalize()
        results['name'] = name
    else:
        return handle_403_page(request, HttpResponseForbidden)

    return render(request, 'dashboard_pr.html', results)