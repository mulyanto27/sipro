from invoice import views_approval
from django.urls import path

from . import views

app_name = "invoice"
urlpatterns = [
    path('', views.index, name='index'),
    path('need-approval', views.get_invoice_filter_by_status, name='invoice_need_approval'),
    path('open-inv/', views.list_open_invoice, name="list_open_invoice"),
    path('pending-inv/', views.list_pending_invoice, name="list_pending_invoice"),
    path('rejected', views.get_invoice_filter_by_status, name='invoice_rejected'),
    path('uploaded-document', views.uploaded_document, name='uploaded_document'),
    path('upload-document/<int:id_po>', views.upload_document, name='upload_document'),
    path('approve-document/<int:id_doc>', views.approve_document, name='approve_doc'),
    path('payment-data/<int:id_po>', views.get_all_payment_data, name='all_data_pembayaran'),
    path('payment-data-inv/<int:id_inv>', views.get_all_payment_data_from_invoice, name='all_data_pembayaran_from_invoice'),
    path('approve-invoice/<int:id_inv>', views_approval.approve_inv, name='approve-invoice'),
    path('reject-invoice/<int:id_inv>', views_approval.view_reject_inv, name='reject-invoice'),
    path('pending-invoice/<int:id_inv>', views_approval.set_inv_pending, name='pending-invoice'),
    path('resubmit-invoice/<int:id_inv>', views_approval.resubmit_invoice, name='resubmit-invoice'),
    path('payment-data/create-payment-data/<int:id_po>-<str:id_inv>', views.create_payment_data, name='create_data_pembayaran'),
    path('create-invoice/<slug:id_po>', views.create_invoice, name='create_invoice'),
    path('edit-invoice/<slug:id_invoice>', views.edit_invoice, name='edit_invoice'),
    # path('need-approval-detail/<str:id>', views.get_need_approval_invoice_detail, name='get_need_approval_invoice_detail'),
    path('payment/<str:tab>/<str:name>', views.dashboard_payment, name='dashboard_payment'),
    path('<str:tab>/<str:name>', views.dashboard_invoice, name='dashboard_invoice'),
    path('<str:id>', views.get_invoice_by_id, name='get_invoice_by_id'),
]