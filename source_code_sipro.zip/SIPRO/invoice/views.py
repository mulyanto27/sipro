from django.http.response import HttpResponse, HttpResponseForbidden, HttpResponseNotFound, HttpResponseServerError
from django.shortcuts import redirect, render
from main.models import *
from main.views import handle_403_page, handle_404_page, handle_500_page
from django.contrib import messages
from decimal import Decimal
from django.contrib.auth.models import User as auth_user
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.core.mail import send_mail
from datetime import datetime

# Create your views here.
def index(request):
    id_role_user = request.session['role_id']
    id_user = request.session['user_id']
    argument = {"title":"List of All Invoice"}
    list_invoice = []
    if id_role_user == 8:
        try:
            subkon = Subkontraktor.objects.get(user_id = id_user)
            data_subkon_id = subkon.data_subkontraktor.id
            list_invoice = Invoice.objects.filter(data_subkontraktor__id=data_subkon_id, status__in=[7,8]).order_by('id')
            argument["list_invoice"] = list_invoice
            argument["subkon"] = subkon
            return render(request, 'home_invoice_subkon.html', argument)
        except:
            return handle_500_page(request, HttpResponseServerError)
    else:
        list_invoice = Invoice.objects.all().order_by('id')
    argument["list_invoice"] = list_invoice
    return render(request, 'home_invoice.html', argument)

def list_open_invoice(request):
    argument = {"title":"List of All Invoice (Open)"}
    list_invoice = Invoice.objects.filter(status = 7).order_by('id')
    argument["list_invoice"] = list_invoice
    return render(request, "home_invoice.html", argument)

def list_pending_invoice(request):
    argument = {"title":"List of All Invoice (Pending)"}
    list_invoice = Invoice.objects.filter(status = 6).order_by('id')
    argument["list_invoice"] = list_invoice
    return render(request, "home_invoice.html", argument)

def get_invoice_filter_by_status(request):
    list_invoice = []
    need_approval = False
    try:
        id_role_user = request.session['role_id']
        id_user = request.session['user_id']
    except:
        return redirect('/login')
    if id_role_user == 5:
        list_invoice = Invoice.objects.filter(status=0, pm__user__id=id_user).order_by('id')
        need_approval = True
        title = "List of Invoice Need PM's Approval"
    elif id_role_user == 3:
        list_invoice = Invoice.objects.filter(status=1).order_by('id')
        need_approval = True
        title = "List of Invoice Need COO's Approval"
    elif id_role_user == 2:
        list_invoice = Invoice.objects.filter(Q(status=2) | Q(status=6)).order_by('id')
        need_approval = True
        title = "List of Invoice Need Director's Approval"
    elif id_role_user == 6:
        list_invoice = Invoice.objects.filter(Q(status=3) | Q(status=4) | Q(status=5)).order_by('id')
        need_approval = True
        title = "List of All Rejected Invoice"
    else:
        return redirect('invoice:index')
    for invoice in list_invoice:
        invoice.grand_total_price = float(invoice.grand_total_price)
        invoice.to_pay = float(invoice.to_pay)
    argument = {
        'list_invoice': list_invoice,
        'title': title,
        'need_approval': need_approval
    }
    return render(request, 'home_invoice.html', argument)

def get_invoice_by_id(request, id, need_approval = False, success_change_status = False, resubmit_invoice=False):
    selected_invoice = Invoice.objects.get(id=id)
    try:
        idUser = request.session['user_id']
    except:
        return redirect('/login')
    ##Mengubah bentuk to pay dan grand total price agar tidak ambigu saat ditampilkan
    selected_invoice.to_pay = float(selected_invoice.to_pay)
    selected_invoice.grand_total_price=float(selected_invoice.grand_total_price)
    invoice_quantity = int(selected_invoice.invoice_quantity)
    po = selected_invoice.po
    category = po.category
    id_category = category.id
    list_komponen = Komponen.objects.filter(invoice_id=id)
    list_item = []
    list_comp = {}
    dokumen = "invoice"

    #Cek tipe formulir. 1 Sitebased, 2 Workbased, 3 Timebased
    formType = po.pr.form_type

    if formType == 1:
        dictSitebased = get_sitebased(dokumen, id)
        list_item = dictSitebased[0]
        list_comp = dictSitebased[1]

    elif formType == 2:
        dictWorkbased = get_workbased(dokumen, id)
        list_item = dictWorkbased[0]
        list_comp = dictWorkbased[1]

    elif formType == 3:
        list_item = get_timebased(dokumen, id)

    is_able_resubmit = check_is_able_to_resubmit(selected_invoice)
    paymentDataBoolean = False
    paymentData = Data_Pembayaran.objects.filter(invoice=selected_invoice)
    if paymentData.exists() :
        paymentDataBoolean = True
    argument = {
        'selected_invoice': selected_invoice,
        'list_item': list_item,
        'category': category,
        'list_comp': list_comp,
        'invoice_quantity': invoice_quantity,
        'idUser' : idUser,
        'success_change_status' : success_change_status,
        'resubmit_invoice' : resubmit_invoice,
        'is_able_resubmit' : is_able_resubmit,
        'paymentDataBoolean' : paymentDataBoolean,
    }
    return render(request, "detail_invoice.html", argument)

"""Views for checking if the time is not in pending interval. """
def check_is_able_to_resubmit(inv):
    email_job_id = inv.email_job.id
    email_job = Worker_Email_Job.objects.get(id = email_job_id)
    status = email_job.approval_status
    if (status != "PENDING"):
        return True

    job = Job.objects.filter(email_job_id = email_job_id).order_by('-id')[0]

    d_now = datetime.now(tz=timezone.utc)
    d_worker_sent_at = job.sent_at

    delta = d_now - d_worker_sent_at

    if (delta.days < 0):
        return False
    else:
        return True

# # Gajadi dipake
# def get_need_approval_invoice_detail(request,id):
#     return get_invoice_by_id(request, id, True)

def create_invoice(request,id_po):
    try:
        username = request.session['username']
        a_user = auth_user.objects.get(username=username)
        user = User.objects.get(user=a_user)
        if user.role.id != 6:
            return handle_403_page(request, HttpResponseForbidden)
    except:
        return redirect('/login')

    po = Purchase_Order.objects.get(id=id_po)
    id_category = po.category_id
    category_obj = Category.objects.get(id=id_category)
    subkontraktor = Data_Subkontraktor.objects.get(id=po.data_subkontraktor_id)
    outstanding_po = 0
    message = ""
    try:
        list_invoice_po = Invoice.objects.filter(po_id=po.id)
        total_top = 0
        for invoice in list_invoice_po:
            total_top += float(invoice.invoice_quantity)
        outstanding_po = 100-total_top
    except:
        outstanding_po = 100
    to_pay = 0
    list_item = []
    list_comp = {}
    dokumen = "po"

    #Cek tipe formulir. 1 Sitebased, 2 Workbased, 3 Timebased
    formType = po.pr.form_type

    if formType == 1:
        dictSitebased = get_sitebased(dokumen, id_po)
        list_item = dictSitebased[0]
        list_comp = dictSitebased[1]

    elif formType == 2:
        dictWorkbased = get_workbased(dokumen, id_po)
        list_item = dictWorkbased[0]
        list_comp = dictWorkbased[1]

    elif formType == 3:
        list_item = get_timebased(dokumen, id_po)

    if request.method =="POST" and request.FILES['supporting_document']:
        no_invoice = request.POST['noInvoice']
        datecreate = request.POST['datecreate']
        notes = request.POST['notes']
        supporting_document = request.FILES['supporting_document']
        invoice_quantity = request.POST['invoiceQuantity']
        chosen_top = float(invoice_quantity)/100
        to_pay = float(po.grand_total_price) * chosen_top
        pm = po.pm
        cekTotalTOP = total_top + float(invoice_quantity)
        director= User.objects.get(role=2)
        coo= User.objects.get(role=3)

        #Khusus untuk invoice terakhir untuk mengatasi miss yang terjadi
        #Apabila PO diedit namun telah ada invoice
        lastInv = float(po.outstanding_po)  == float(invoice_quantity)
        if lastInv:
            #Cek sum grand_total_price invoice yang dimiliki po
            allInv = Invoice.objects.filter(po=po)
            sumPriceAllInv = 0
            for inv in allInv:
                sumPriceAllInv = sumPriceAllInv + float(inv.grand_total_price)
            trueToPay = float(po.grand_total_price) - sumPriceAllInv
            #Cek apakah harga invoice terakhir sesuai dengan sisa jumlah yang memang seharusnya di invoicekan
            #Jika tidak sama berarti ada perubahan pada PO saat PO tersebut telah memiliki invoice
            if to_pay != trueToPay:
                to_pay = trueToPay

        invoiceCreated = False
        if cekTotalTOP <= 100:

            try:
                job = setup_deadline(pm.user.email, no_invoice, po.no_po)
                send_email(pm.user.email, no_invoice, po.no_po)
                invoice = Invoice.objects.create(no_invoice=no_invoice,po=po, invoice_quantity=invoice_quantity,
                                data_subkontraktor=subkontraktor,category=category_obj, date=datecreate,
                                status=0,feedback='-', supporting_document = supporting_document, pm=pm,
                                notes = notes, grand_total_price=to_pay, to_pay = to_pay,
                                prepared_by=user, director=director, coo=coo, email_job = job)
                invoiceCreated = True
            except Exception as e:
                if invoiceCreated:
                    invoice.delete()
                messages.info(request, "Oopss. Something gone wrong. Invoice can't be created. Please try again.", extra_tags='danger')
                return redirect('invoice:create_invoice', id_po = po.id)

            #Simpan old data ke variable
            old_total_bill = po.total_bill
            old_outstanding_bill = po.outstanding_bill
            old_outstanding_po = po.outstanding_po

            try:
                #Adjustment PO
                po.total_bill = float(po.total_bill) + float(invoice.grand_total_price)
                po.outstanding_bill = float(po.outstanding_bill) + float(invoice.to_pay)
                po.outstanding_po = float(po.outstanding_po) - float(invoice_quantity)
                po.save()
            except Exception as e:
                invoice.delete()
                messages.info(request, "Oopss. Something gone wrong. Related Purchase Order can't be updated. Invoice can't be created. Please try again.", extra_tags='danger')
                return redirect('invoice:create_invoice', id_po = po.id)

            #Case Kategori PO adalah Sitebased
            if formType == 1:
                try:
                    createSitebased(invoice, list_item, list_comp, chosen_top, lastInv)
                    messages.info(request, 'Success! Invoice has been created.', extra_tags='success')
                    return redirect('invoice:get_invoice_by_id',id=invoice.id)
                except Exception as e:
                    message = "Oopss. Something gone wrong when create invoice sitebased components. Invoice can't be created"
                    if invoiceCreated:
                        invoice.delete()
                    #Revert PO
                    po.total_bill = old_total_bill
                    po.outstanding_bill = old_outstanding_bill
                    po.outstanding_po = old_outstanding_po
                    po.save()

            #Case Kategori PO adalah Workbased
            elif formType == 2:
                try:
                    createWorkbased(invoice, list_item, list_comp, chosen_top, lastInv)
                    messages.info(request, 'Success! Invoice has been created.', extra_tags='success')
                    return redirect('invoice:get_invoice_by_id',id=invoice.id)
                except Exception as e:
                    message = "Oopss. Something gone wrong when create invoice workbased components. Invoice can't be created"
                    if invoiceCreated:
                        invoice.delete()
                    #Revert PO
                    po.total_bill = old_total_bill
                    po.outstanding_bill = old_outstanding_bill
                    po.outstanding_po = old_outstanding_po
                    po.save()

            #Case Kategori PO adalah Timebased atau Rental
            elif formType == 3:
                try:
                    createTimebased(invoice, list_item, chosen_top, lastInv)
                    messages.info(request, 'Success! Invoice has been created.', extra_tags='success')
                    return redirect('invoice:get_invoice_by_id',id=invoice.id)
                except Exception as e:
                    message = "Oopss. Something gone wrong when create invoice timebased components. Invoice can't be created"
                    if invoiceCreated:
                        invoice.delete()
                    #Revert PO
                    po.total_bill = old_total_bill
                    po.outstanding_bill = old_outstanding_bill
                    po.outstanding_po = old_outstanding_po
                    po.save()

        else:
            if cekTotalTOP > 100:
                message = "Oops. Invoice Quantity exceed max value."
            else:
                message = "Oops. Something gone wrong."

    argument={
        'po':po,
        'subkontraktor':subkontraktor,
        'category':category_obj,
        'list_item':list_item,
        'outstanding_po':outstanding_po,
        'list_comp': list_comp,
        'message': message,
    }

    return render(request,"create_invoice.html",argument)

def get_timebased(dokumen, id_dokumen):
    list_item =[]
    if(dokumen == "po"):
        list_komponen_timebased = Komponen.objects.filter(po_id=id_dokumen)
    else:
        list_komponen_timebased = Komponen.objects.filter(invoice_id=id_dokumen)
    for komponen in list_komponen_timebased:
        timebased_obj = Timebased.objects.get(komponen_id=komponen.id)
        list_item.append(timebased_obj)
    return list_item

def get_sitebased(dokumen, id_dokumen):
    list_item =[]
    list_comp = {}
    dictSitebased = {}
    if(dokumen == "po"):
        list_komponen = Komponen.objects.filter(po_id=id_dokumen)
    else:
        list_komponen = Komponen.objects.filter(invoice_id=id_dokumen)
    for komponen in list_komponen:
        sitebased = Sitebased.objects.get(komponen_id=komponen.id)
        list_item.append(sitebased)
        list_site = Item_Sitebased.objects.filter(sitebased=sitebased)
        list_comp[sitebased] = list_site
    dictSitebased[0] = list_item
    dictSitebased[1] = list_comp
    return dictSitebased

def get_workbased(dokumen, id_dokumen):
    list_item = []
    list_comp = {}
    dictWorkbased = {}
    if(dokumen == "po"):
        list_komponen = Komponen.objects.filter(po_id=id_dokumen)
    else:
        list_komponen = Komponen.objects.filter(invoice_id=id_dokumen)
    for komponen in list_komponen:
        workbased = Workbased.objects.get(komponen_id=komponen.id)
        list_item.append(workbased)
        list_site = Item_Workbased.objects.filter(workbased=workbased)
        list_comp[workbased] = list_site
    dictWorkbased[0] = list_item
    dictWorkbased[1] = list_comp
    return dictWorkbased

def createTimebased(invoice, list_item, chosen_top, lastInv):
    for item in list_item:
        komponen = Komponen.objects.create(invoice=invoice)
        itembarang = item.item
        item_detail = item.item_detail
        start_date = item.start_date
        end_date = item.end_date
        period = item.period
        quantity = item.quantity
        unit_price = item.unit_price
        discount = item.discount
        total_price = item.total_price
        invoice_comp_qty = float(quantity) * chosen_top

        #Sesuaikan invoice_comp_qty untuk invoice terakhir dan jika melebihi
        if lastInv or (float(item.invoice_comp_qty)+float(invoice_comp_qty) > float(item.quantity)):
            invoice_comp_qty = float(item.quantity) - float(item.invoice_comp_qty)

        value_discount = invoice_comp_qty*float(unit_price)*float(discount)/100
        total_bill = invoice_comp_qty*float(unit_price) - value_discount
        timebased = Timebased.objects.create(komponen=komponen, item=itembarang, item_detail=item_detail,
            start_date=start_date, end_date=end_date, period=period, quantity=quantity, unit_price=unit_price,
            discount=discount, total_price=total_price, invoice_comp_qty=invoice_comp_qty, total_bill=total_bill,
            timebased_po=item)
        
        #Update invoice_comp_qty pada Timebased untuk komponen PO
        item.invoice_comp_qty = float(item.invoice_comp_qty) + float(invoice_comp_qty)
        item.save()

def createSitebased(invoice, list_item, list_comp, chosen_top, lastInv):
    for item in list_item:
         komponen = Komponen.objects.create(invoice=invoice)
         site_id = item.site_id
         site_name = item.site_name
         description = item.description

         sitebased = Sitebased.objects.create(komponen=komponen, site_id=site_id, site_name=site_name, description=description)

         #Loop untuk tiap item sitebased
         for item_sb in list_comp[item]:
            sow = item_sb.sow
            quantity = item_sb.quantity
            unit_price = item_sb.unit_price
            discount = item_sb.discount
            total_price = item_sb.total_price
            invoice_comp_qty = float(quantity) * chosen_top
            
            
            #Sesuaikan invoice_comp_qty untuk invoice terakhir dan jika melebihi
            if lastInv or (float(item_sb.invoice_comp_qty)+float(invoice_comp_qty) > float(item_sb.quantity)):
                invoice_comp_qty = float(item_sb.quantity) - float(item_sb.invoice_comp_qty)

            value_discount = invoice_comp_qty*float(unit_price)*float(discount)/100
            total_bill = invoice_comp_qty*float(unit_price) - value_discount
            item_sitebased = Item_Sitebased.objects.create(sitebased=sitebased, sow=sow, quantity=quantity,
                                                           invoice_comp_qty=invoice_comp_qty,
                                                           unit_price=unit_price, discount=discount,
                                                           total_price=total_price, total_bill=total_bill,
                                                           item_sb_po=item_sb)

            #Update invoice_comp_qty pada Item_Sitebased untuk komponen PO
            item_sb.invoice_comp_qty = float(item_sb.invoice_comp_qty) + float(invoice_comp_qty)
            item_sb.save()

def createWorkbased(invoice, list_item, list_comp, chosen_top, lastInv):
    for item in list_item:
        komponen = Komponen.objects.create(invoice=invoice)
        sow = item.sow
        description = item.description
        workbased = Workbased.objects.create(komponen=komponen, sow=sow, description=description)

        #Loop untuk tiap item workbased
        for item_wb in list_comp[item]:
            site_id = item_wb.site_id
            site_name = item_wb.site_name
            quantity = item_wb.quantity
            invoice_comp_qty = float(quantity) * chosen_top
            unit_price = item_wb.unit_price
            discount = item_wb.discount
            total_price = item_wb.total_price

            #Sesuaikan invoice_comp_qty untuk invoice terakhir dan jika melebihi
            if lastInv or (float(item_wb.invoice_comp_qty)+float(invoice_comp_qty) > float(item_wb.quantity)):
                invoice_comp_qty = float(item_wb.quantity) - float(item_wb.invoice_comp_qty)

            value_discount = invoice_comp_qty*float(unit_price)*float(discount)/100
            total_bill = invoice_comp_qty*float(unit_price) - value_discount

            item_workbased = Item_Workbased.objects.create(workbased=workbased, site_id=site_id, site_name=site_name,
                                                           quantity=quantity, invoice_comp_qty=invoice_comp_qty,
                                                           unit_price=unit_price, discount=discount,
                                                           total_price=total_price, total_bill=total_bill,
                                                           item_wb_po=item_wb)

            #Update invoice_comp_qty pada Item_Workbased untuk komponen PO
            item_wb.invoice_comp_qty = float(item_wb.invoice_comp_qty) + float(invoice_comp_qty)
            item_wb.save()

def edit_invoice(request,id_invoice):
    invoice = Invoice.objects.get(id=id_invoice)

    try:
        username = request.session['username']
        if username != invoice.prepared_by.user.username:
            return handle_403_page(request, HttpResponseForbidden)
    except:
        return redirect('/login')

    po = Purchase_Order.objects.get(id=invoice.po_id)
    id_category = po.category_id
    category_obj = Category.objects.get(id=id_category)
    subkontraktor = Data_Subkontraktor.objects.get(id=po.data_subkontraktor_id)
    outstanding_po = 0
    message = ""
    try:
        list_invoice_po = Invoice.objects.filter(po_id=po.id)
        total_top = 0
        for inv in list_invoice_po:
            total_top += float(inv.invoice_quantity)
        outstanding_po = 100-total_top+float(invoice.invoice_quantity)
    except:
        outstanding_po = 100
    to_pay = 0
    list_item =[]
    list_item = []
    list_comp = {}
    dictSitebased = {}
    dictWorkbased = {}
    dokumen = "invoice"

    #Cek tipe formulir. 1 Sitebased, 2 Workbased, 3 Timebased
    formType = po.pr.form_type

    if formType == 1:
        dictSitebased = get_sitebased(dokumen, id_invoice)
        list_item = dictSitebased[0]
        list_comp = dictSitebased[1]

    elif formType == 2:
        dictWorkbased = get_workbased(dokumen, id_invoice)
        list_item = dictWorkbased[0]
        list_comp = dictWorkbased[1]

    elif formType == 3:
        list_item = get_timebased(dokumen, id_invoice)

    if request.method =="POST":
        no_invoice = request.POST['noInvoice']
        datecreate = request.POST['datecreate']
        feedback = request.POST['feedback']
        notes = request.POST['notes']
        invoice_quantity = request.POST['invoiceQuantity']
        chosen_top = float(invoice_quantity)/100
        inv_grandtotalprice = float(po.grand_total_price) * chosen_top
        supporting_document_field = False
        cekTotalTOP = total_top - float(invoice.invoice_quantity) + float(invoice_quantity)

        lastInv = False
        totalHargaInvoiceSeharusnya = (float(invoice.invoice_quantity)/100) * float(po.grand_total_price)

        #Memastikan bahwa invoice tersebut adalah invoice terakhir
        #Tidak bisa hanya menggunakan outstanding_po karena mungkin outstanding_po telah 0 namun inv yang diedit bukan inv terakhir
        lastInvObj = Invoice.objects.filter(po__id = po.id).latest('id')
        if po.outstanding_po == 0 and invoice == lastInvObj:
            #Memastikan bahwa invoice top sama seperti sebelumnya
            #Jika sama, grand_total_price juga harus sama seperti sebelumnya
            #Jika top berkurang maka inv tersebut bukan inv terakhir sehingga akan dijalankan normal flow
            #Case khusus diterapkan pada grand_total_price dan invoice_comp_qty
            if float(invoice_quantity) == float(invoice.invoice_quantity):
                inv_grandtotalprice = invoice.grand_total_price
                lastInv = True
        #Case apabila invoice biasa berubah menjadi invoice terakhir
        elif float(invoice.invoice_quantity) + float(po.outstanding_po) == float(invoice_quantity):
            lastInv = True

            #Cek sum grand_total_price invoice yang dimiliki po
            allInv = Invoice.objects.filter(po=po)
            sumPriceAllInv = 0
            for inv in allInv:
                sumPriceAllInv = sumPriceAllInv + float(inv.grand_total_price)
            trueToPay = float(po.grand_total_price) - sumPriceAllInv + float(invoice.grand_total_price)
            #Ganti grand_total_price di invoice menjadi total yang belum di invoicekan
            inv_grandtotalprice = trueToPay
        else:
            inv_grandtotalpriceAwalPO = float(invoice.grand_total_price) / (float(invoice.invoice_quantity)/100)
            inv_grandtotalprice = float(inv_grandtotalpriceAwalPO) * chosen_top

        try:
            supporting_document = request.FILES['supporting_document']
            supporting_document_field = True
        except:
            supporting_document_field = False

        if cekTotalTOP <=100 :
            try:
                #Get Old Invoice Data
                old_invoice_gtp = invoice.grand_total_price
                old_invoice_topay = invoice.to_pay
                old_invoice_quantity = invoice.invoice_quantity
                #Update New Invoice Data
                invoice.no_invoice=no_invoice
                invoice.date=datecreate
                invoice.feedback=feedback
                invoice.notes=notes
                invoice.invoice_quantity=invoice_quantity
                invoice.grand_total_price=inv_grandtotalprice
                invoice.to_pay=inv_grandtotalprice
                invoice.status=0
                if supporting_document_field:
                    invoice.supporting_document=supporting_document
                invoice.save()
            except Exception as e:
                messages.info(request, "Oopss. Something gone wrong. Invoice can't be updated. Please try again.", extra_tags='danger')
                return redirect('invoice:edit_invoice', id_invoice = invoice.id)

            #Get Old PO Data
            old_po_total_bill = float(po.total_bill)
            old_po_outstanding_bill = float(po.outstanding_bill)
            old_po_outstanding_po = float(po.outstanding_po)
            #Adjustment PO
            try:
                po.total_bill = float(po.total_bill) - float(old_invoice_gtp) + float(invoice.grand_total_price)
                po.outstanding_bill = float(po.outstanding_bill) - float(old_invoice_topay) + float(invoice.to_pay)
                po.outstanding_po = float(po.outstanding_po) + float(old_invoice_quantity) - float(invoice_quantity)
                po.save()
            except Exception as e:
                #Revert PO Data
                po.total_bill = old_total_bill
                po.outstanding_bill = old_outstanding_bill
                po.outstanding_po = old_outstanding_po

                messages.info(request, "Oopss. Something gone wrong. Related Purchase Order can't be updated", extra_tags='danger')
                return redirect('invoice:edit_invoice', id_invoice = invoice.id)

            # add deadline
            job = setup_deadline(invoice.pm.user.email, no_invoice, po.no_po)
            invoice.email_job = job
            send_email(invoice.pm.user.email, no_invoice, po.no_po)
            invoice.save()
            
            #Case Kategori PO adalah Timebased atau Rental
            if formType == 3:
                try:
                    updateTimebased(list_item, float(invoice.invoice_quantity)/100, lastInv)
                    messages.info(request, 'Success! Invoice has been edited.', extra_tags='success')
                    return redirect('invoice:get_invoice_by_id',id=invoice.id)
                except Exception as e:
                    message = "Oopss. Something gone wrong. Components can't be updated"

            #Untuk Sitebased dan Workbased
            elif formType == 2:
                try:
                    updateWorkbased(list_item, list_comp, float(invoice.invoice_quantity)/100, lastInv)
                    messages.info(request, 'Success! Invoice has been edited.', extra_tags='success')
                    return redirect('invoice:get_invoice_by_id',id=invoice.id)
                except Exception as e:
                    message = "Oopss. Something gone wrong. Components can't be updated"
                        #Untuk Sitebased dan Workbased
            elif formType == 1:
                try:
                    updateSitebased(list_item, list_comp, float(invoice.invoice_quantity)/100, lastInv)
                    messages.info(request, 'Success! Invoice has been edited.', extra_tags='success')
                    return redirect('invoice:get_invoice_by_id',id=invoice.id)
                except Exception as e:
                    message = "Oopss. Something gone wrong. Components can't be updated"

        else:
            if cekTotalTOP > 100:
                message = "Oops. Invoice Quantity exceed max value."
            else:
                message = "Oops. Something gone wrong."

    argument={
        'po':po,
        'subkontraktor':subkontraktor,
        'category':category_obj,
        'list_item':list_item,
        'outstanding_po':outstanding_po,
        'invoice_quantity':float(invoice.invoice_quantity),
        'list_comp': list_comp,
        'invoice' : invoice,
        'date' : str(invoice.date),
        'message' : message,
    }

    return render(request,"edit_invoice.html",argument)

def updateTimebased(list_item, chosen_top, lastInv):
    inv_amount = 0
    selected_invoice = list_item[0].komponen.invoice
    for item in list_item:
        old_invoice_comp_quantity = item.invoice_comp_qty
        invoice_comp_qty = float(item.quantity) * chosen_top
        
        timebased_po = item.timebased_po
        kondisi_awal_inv_comp_qty = float(timebased_po.invoice_comp_qty) - float(old_invoice_comp_quantity)
        
        if lastInv or (kondisi_awal_inv_comp_qty+float(invoice_comp_qty) > float(timebased_po.quantity)) :
            invoice_comp_qty = float(timebased_po.quantity) - kondisi_awal_inv_comp_qty
            item.invoice_comp_qty = invoice_comp_qty
        else:
            item.invoice_comp_qty = invoice_comp_qty
        
        value_discount = invoice_comp_qty*float(timebased_po.unit_price)*float(timebased_po.discount)/100
        total_bill = invoice_comp_qty*float(timebased_po.unit_price) - value_discount
        inv_amount += total_bill

        timebased_po.invoice_comp_qty = kondisi_awal_inv_comp_qty + invoice_comp_qty
        timebased_po.save()
        item.total_bill = total_bill
        item.save()
    selected_invoice.grand_total_price = inv_amount
    selected_invoice.to_pay = inv_amount
    selected_invoice.save()

# Fungsi untuk update Workbased
def updateWorkbased(list_item, list_comp, chosen_top, lastInv):
    inv_amount = 0
    selected_invoice = list_item[0].komponen.invoice
    for item in list_item:
        #Loop untuk tiap item workbased
        for item_wb in list_comp[item]:
            old_invoice_comp_quantity = item_wb.invoice_comp_qty
            
            invoice_comp_qty = float(item_wb.quantity)*chosen_top
            item_wb_po = item_wb.item_wb_po
            kondisi_awal_inv_comp_qty = float(item_wb_po.invoice_comp_qty) - float(old_invoice_comp_quantity)

            if lastInv or (kondisi_awal_inv_comp_qty+float(invoice_comp_qty) > float(item_wb_po.quantity)) :
                invoice_comp_qty = float(item_wb_po.quantity) - kondisi_awal_inv_comp_qty
                item_wb.invoice_comp_qty = invoice_comp_qty
            else:
                item_wb.invoice_comp_qty = invoice_comp_qty
            
            value_discount = invoice_comp_qty*float(item_wb_po.unit_price)*float(item_wb_po.discount)/100
            total_bill = invoice_comp_qty*float(item_wb_po.unit_price) - value_discount
            inv_amount += total_bill

            item_wb_po.invoice_comp_qty = kondisi_awal_inv_comp_qty + invoice_comp_qty
            item_wb_po.save()
            item_wb.total_bill = total_bill
            item_wb.save()
    selected_invoice.grand_total_price = inv_amount
    selected_invoice.to_pay = inv_amount
    selected_invoice.save()

def updateSitebased(list_item, list_comp, chosen_top, lastInv):
    inv_amount = 0
    selected_invoice = list_item[0].komponen.invoice
    for item in list_item:
        #Loop untuk tiap item workbased
        for item_sb in list_comp[item]:
            old_invoice_comp_quantity = item_sb.invoice_comp_qty
            
            invoice_comp_qty = float(item_sb.quantity)*chosen_top
            item_sb_po = item_sb.item_sb_po
            kondisi_awal_inv_comp_qty = float(item_sb_po.invoice_comp_qty) - float(old_invoice_comp_quantity)

            if lastInv or (kondisi_awal_inv_comp_qty+float(invoice_comp_qty) > float(item_sb_po.quantity)) :
                invoice_comp_qty = float(item_sb_po.quantity) - kondisi_awal_inv_comp_qty
                item_sb.invoice_comp_qty = invoice_comp_qty
            else:
                item_sb.invoice_comp_qty = invoice_comp_qty
            
            value_discount = invoice_comp_qty*float(item_sb_po.unit_price)*float(item_sb_po.discount)/100
            total_bill = invoice_comp_qty*float(item_sb_po.unit_price) - value_discount
            inv_amount += total_bill

            item_sb_po.invoice_comp_qty = kondisi_awal_inv_comp_qty + invoice_comp_qty
            item_sb_po.save()
            item_sb.total_bill = total_bill
            item_sb.save()
    selected_invoice.grand_total_price = inv_amount
    selected_invoice.to_pay = inv_amount
    selected_invoice.save()

def get_all_payment_data(request, id_po):
    list_data_pembayaran = Data_Pembayaran.objects.filter(invoice__po=id_po)
    po = Purchase_Order.objects.get(id=id_po)
    argument = {
        'list_data_pembayaran': list_data_pembayaran,
        'id_po': id_po,
        'id_inv': 0,
        'po' : po
    }
    return render(request, 'home_data_pembayaran.html', argument)

def get_all_payment_data_from_invoice(request, id_inv):
    invoice = Invoice.objects.get(id = id_inv)
    list_data_pembayaran = Data_Pembayaran.objects.filter(invoice__id=id_inv)
    id_po = invoice.po.id
    argument = {
        'list_data_pembayaran': list_data_pembayaran,
        'id_po': id_po,
        'id_inv': id_inv,
        'invoice': invoice,
    }
    return render(request, 'home_data_pembayaran_invoice.html', argument)


def create_payment_data(request, id_po, id_inv):
    if request.session['role_id'] != 7:
        return handle_403_page(request,HttpResponseForbidden)
    if request.method == 'POST' and request.FILES['proof_of_payment']:
        invoice_id = request.POST['invoice']
        payment_amount = Decimal(request.POST['payment_amount']) 
        payment_date = request.POST['payment_date']
        proof_of_payment = request.FILES['proof_of_payment']
        try:
            invoice = Invoice.objects.get(id = invoice_id)
            data_pembayaran = Data_Pembayaran(
                invoice=invoice,
                payment_amount=payment_amount,
                payment_date=payment_date)
            data_pembayaran.proof_of_payment = proof_of_payment
            data_pembayaran.save()

            invoice.to_pay = invoice.to_pay - payment_amount
            # set to paid
            if (invoice.to_pay<=0):
                invoice.status = 8
            invoice.save()

            adjustment_po(payment_amount, data_pembayaran)
            
            messages.info(request,
                          'Payment data created',
                          extra_tags='success')
            if id_inv != 0:
                return redirect("invoice:all_data_pembayaran_from_invoice", id_inv=invoice.id)
            return redirect("invoice:all_data_pembayaran", id_po=id_po)
        except:
            messages.info(request,
                          'Failed to create payment data',
                          extra_tags='failed')
            if id_inv != 0:
                return redirect("invoice:all_data_pembayaran_from_invoice", id_inv=invoice.id)
            return redirect("invoice:create_data_pembayaran", id_po=id_po)
    else:
        po = Purchase_Order.objects.get(id=id_po)
        list_invoice = Invoice.objects.filter(po=po, status=7).order_by('id')
        argument = {"po": po, "list_invoice": list_invoice, 'id_inv': id_inv}
        return render(request, 'create_data_pembayaran.html', argument)

def adjustment_po(payment_amount, data_pembayaran):
    po = data_pembayaran.invoice.po
    po.total_paid_off_bill += payment_amount
    po.outstanding_bill = po.total_bill - po.total_paid_off_bill
    po.outstanding_grand_total = po.grand_total_price - po.total_paid_off_bill 
    if (po.outstanding_grand_total<=0):
        po.status = 4
    po.save()


def dashboard_invoice(request, tab, name):
    if not (request.session['role_id'] == 8):
        results = {}
        if tab == 'category':
            #get all data about each invoice based on its categories
            invoice_per_category = Invoice.objects\
                .filter(category__category_name=name)\
                .order_by('no_invoice')
            results['list_invoice'] = invoice_per_category
        elif tab == 'project':
            #get all data about each invoice based on its project name
            invoice_per_project = Invoice.objects\
                .filter(po__pr__project__name=name)\
                .order_by('no_invoice')
            results['list_invoice'] = invoice_per_project
        elif tab == 'area':
            #get all data about each invoice based on its area name
            invoice_per_area = Invoice.objects\
                .filter(po__pr__area__name=name)\
                .order_by('no_invoice')
            results['list_invoice'] = invoice_per_area
        else:
            return handle_404_page(request, HttpResponseNotFound)
        
        results['tab'] = tab.capitalize()
        results['name'] = name
    else:
        return handle_403_page(request, HttpResponseForbidden)
    return render(request, 'dashboard_invoice.html', results)

def dashboard_payment(request, tab, name):
    if not (request.session['role_id'] == 8):
        results = {}
        if tab == 'category':
            #get all data about each payment based on its categories
            payment_per_category = Purchase_Order.objects\
                .filter(category__category_name=name)\
                .order_by('no_po')
            results['list_payment'] = payment_per_category
        elif tab == 'project':
            #get all data about each payment based on its project name
            payment_per_project = Purchase_Order.objects\
                .filter(pr__project__name=name)\
                .order_by('no_po')
            results['list_payment'] = payment_per_project
        elif tab == 'area':
            #get all data about each payment based on its area name
            payment_per_area = Purchase_Order.objects\
                .filter(pr__area__name=name)\
                .order_by('no_po')
            results['list_payment'] = payment_per_area
        else:
            return handle_404_page(request, HttpResponseNotFound)
        
        results['tab'] = tab.capitalize()
        results['name'] = name
    else:
        return handle_403_page(request, HttpResponseForbidden)
    
    return render(request, 'dashboard_payment.html', results)
"""For sending email and setup schedule"""
def setup_deadline(email_des, no_inv, no_po):
    body = "Anda perlu menyetujui Invoice "+ no_inv +" dari Purchase Order "+ no_po +" melalui link berikut http://cashpoint.citius.co.id/invoice/need-approval"
    job = Worker_Email_Job(
        subject="[Info] Need Approval for Invoice {} from PO {}".format(no_inv, no_po),
        message=body,
        email_des=email_des,
        approval_status="WAITING APPROVAL")
    job.save()
    return job

def send_email(email_des, no_inv, no_po):
    body = "Anda perlu menyetujui Invoice "+ no_inv +" dari Purchase Order "+ no_po +" melalui link berikut http://cashpoint.citius.co.id/invoice/need-approval"
    send_mail(
        "[Info] Need Approval for Invoice {} from PO {}".format(no_inv, no_po),
        body,
        "citius.sipro@gmail.com", [email_des], False)

def uploaded_document(request):
    id_role_user = request.session['role_id']
    id_user = request.session['user_id']
    list_doc = []
    if id_role_user == 8:
        try:
            subkon = Subkontraktor.objects.get(user_id = id_user)
            data_subkon_id = subkon.data_subkontraktor.id
            list_doc = Dokumen_Pembayaran_Subkontraktor.objects.filter(po__data_subkontraktor__id=data_subkon_id).order_by('id')
        except:
            print("Failed to get subkontraktor data")
    elif id_role_user == 6:
       try:
            list_doc = Dokumen_Pembayaran_Subkontraktor.objects.all().order_by('id')
       except:
            print("There is no uploaded documents")
    else:
       return handle_403_page(request, HttpResponseForbidden)

    argument = {
        'list_doc': list_doc,
    }
    return render(request, 'uploaded_documents.html', argument)

def upload_document(request, id_po):
    if request.session['role_id'] != 8:
        return handle_403_page(request,HttpResponseForbidden)
    po = Purchase_Order.objects.get(id=id_po)
    supplier = po.data_subkontraktor.vendor_name
    message = ''
    if request.method == 'POST' and request.FILES['supporting_document']:
        supporting_document = request.FILES['supporting_document']
        notes = request.POST['notes']
        try:
            dokumen = Dokumen_Pembayaran_Subkontraktor.objects.create(po=po, date_uploaded=datetime.now(),
                                                                      attachment=supporting_document, notes=notes,
                                                                      status=0)
            dokumen.save()
            messages.info(request, 'Success! New document has been uploaded.', extra_tags='success')
            return redirect("invoice:uploaded_document")
        except:
            message="Error. A problem has been occured while saving data. Please try to fill the form again."
    else:
        argument = {"po":po, "supplier":supplier, "message":message}
        return render(request, 'upload_document.html', argument)

def approve_document(request, id_doc):
    if request.session['role_id'] != 6:
        return handle_403_page(request,HttpResponseForbidden)
    try:
        dokumen = Dokumen_Pembayaran_Subkontraktor.objects.get(id=id_doc)
        dokumen.status = 1
        dokumen.save()
        messages.info(request, 'Success! A document for PO ' + dokumen.po.no_po + ' has been approved.', extra_tags='success')
        return redirect("invoice:uploaded_document")
    except:
        message="Error. A problem has been occured. Please try again."
        return redirect("invoice:uploaded_document")
