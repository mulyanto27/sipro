from django.http.response import HttpResponseForbidden, HttpResponseNotFound
from main.views import handle_403_page, handle_404_page
from django.shortcuts import render
from main.models import *
from django.core.mail import send_mail
from . import views


# ---APPROVE---
def approve_inv(request, id_inv):
    role_id = request.session['role_id']
    if (role_id == 5):
        return approve_inv_by_pm(request, id_inv)
    elif (role_id == 3):
        return approve_inv_by_coo(request, id_inv)
    elif (role_id == 2):
        return approve_inv_by_director(request, id_inv)
    else:
        return handle_403_page(request, HttpResponseForbidden)


def approve_inv_by_pm(request, id):
    inv = Invoice.objects.get(id=id)
    inv.status = 1
    inv.feedback = ""
    inv.save()
    set_approve_status_job(inv.email_job.id)
    send_email(inv.coo.user.email, inv.no_invoice, inv.po.no_po)
    job = setup_deadline(inv.coo.user.email, inv.no_invoice, inv.po.no_po)
    inv.email_job = job
    inv.save()
    return views.get_invoice_by_id(request=request,
                                   id=id,
                                   need_approval=False,
                                   success_change_status=True)


def approve_inv_by_coo(request, id):
    inv = Invoice.objects.get(id=id)
    inv.status = 2
    inv.feedback = ""
    inv.save()
    set_approve_status_job(inv.email_job.id)
    send_email(inv.director.user.email, inv.no_invoice, inv.po.no_po)
    job = setup_deadline(inv.director.user.email, inv.no_invoice, inv.po.no_po)
    inv.email_job = job
    inv.save()
    return views.get_invoice_by_id(request=request,
                                   id=id,
                                   need_approval=False,
                                   success_change_status=True)


def approve_inv_by_director(request, id):
    inv = Invoice.objects.get(id=id)
    inv.status = 7
    inv.feedback = ""
    inv.save()
    set_approve_status_job(inv.email_job.id)
    return views.get_invoice_by_id(request=request,
                                   id=id,
                                   need_approval=False,
                                   success_change_status=True)


def set_approve_status_job(worker_id):
    job = Worker_Email_Job.objects.get(id=worker_id)
    job.approval_status = "APPROVED"
    job.save()


def setup_deadline(email_des, no_inv, no_po):
    body = "Anda perlu menyetujui Invoice "+ no_inv +" dari Purchase Order "+ no_po +"melalui link berikut http://cashpoint.citius.co.id/invoice/need-approval"
    job = Worker_Email_Job(
        subject="[Info] Need Approval for Invoice {} from PO {}".format(no_inv, no_po),
        message=body,
        email_des=email_des,
        approval_status="WAITING APPROVAL")
    job.save()
    return job

"""Views for sending email to selected Destination"""
def send_email(email_des, no_inv, no_po):
    body = "Anda perlu menyetujui Invoice "+ no_inv +" dari Purchase Order "+ no_po +"melalui link berikut http://cashpoint.citius.co.id/invoice/need-approval"
    send_mail(
        "[Info] Need Approval for Invoice {} from PO {}".format(no_inv, no_po),
        body,
        "citius.sipro@gmail.com", [email_des], False)


"""Views for handle rejection by each actors"""
def reject_inv_by_pm(id, feedback):
    inv = Invoice.objects.get(id=id)
    inv.feedback = feedback
    inv.status = 3
    inv.save()
    set_reject_status_job(inv.email_job.id)


def reject_inv_by_coo(id, feedback):
    inv = Invoice.objects.get(id=id)
    inv.feedback = feedback
    inv.status = 4
    inv.save()
    set_reject_status_job(inv.email_job.id)


def reject_inv_by_director(id, feedback):
    inv = Invoice.objects.get(id=id)
    inv.feedback = feedback
    inv.status = 5
    inv.save()
    set_reject_status_job(inv.email_job.id)


def view_reject_inv(request, id_inv):
    feedback = request.POST['feedback-input']
    role_id = request.session['role_id']
    if (role_id == 5):
        reject_inv_by_pm(id_inv, feedback)
    elif (role_id == 3):
        reject_inv_by_coo(id_inv, feedback)
    elif (role_id == 2):
        reject_inv_by_director(id_inv, feedback)
    else:
        request.method = 'GET'
        return handle_403_page(request=request,
                               exception=HttpResponseForbidden)
    return views.get_invoice_by_id(request=request,
                                   id=id_inv,
                                   need_approval=False,
                                   success_change_status=True)


def set_reject_status_job(worker_id):
    job = Worker_Email_Job.objects.get(id=worker_id)
    job.approval_status = "REJECTED"
    job.save()


"""Views for setup worker schedule for Pending Invoice Status"""
def set_inv_pending(request, id_inv):
    inv = Invoice.objects.get(id=id_inv)
    inv.status = 6
    inv.save()
    set_approve_status_job(inv.email_job.id)
    send_email_pending(inv.prepared_by.user.email,inv.no_invoice, inv.po.no_po)
    job = setup_deadline_pending(inv.prepared_by.user.email, inv.no_invoice, inv.po.no_po)
    inv.email_job = job
    inv.save()
    return views.get_invoice_by_id(request=request,
                                   id=id_inv,
                                   need_approval=False,
                                   success_change_status=True)

def send_email_pending(email_des, no_inv, no_po):
    url_sistem = "http://cashpoint.citius.co.id/invoice/pending-inv/"
    body = "Director memutuskan Invoice {} dari Purchase Order {} untuk dipending. Silakan memantau status invoice tersebut melalui link berikut {}".format(no_inv, no_po, url_sistem)
    send_mail(
        "[Info] Invoice {} from PO {} is Set to Pending".format(no_inv, no_po),
        body,
        "citius.sipro@gmail.com", [email_des], False)

def setup_deadline_pending(email_des, no_inv, no_po):
    url_sistem = "http://cashpoint.citius.co.id/invoice/pending-inv/"
    body = "Director masih belum menyetujui Invoice {} dari Purchase Order {}. Silakan ingatkan melalui link berikut {}".format(no_inv, no_po, url_sistem)
    job = Worker_Email_Job(subject="[Info] Remind Director to Approve Invoice {} from PO {}".format(no_inv, no_po),
                           message=body,
                           email_des=email_des,
                           approval_status="PENDING")
    job.save()
    return job
    
"""Views for resubmitting invoice"""
def resubmit_invoice(request,id_inv):
    inv = Invoice.objects.get(id=id_inv)
    set_approve_status_job(inv.email_job.id)
    send_email(inv.director.user.email,inv.no_invoice, inv.po.no_po)
    job = setup_deadline_pending(inv.prepared_by.user.email, inv.no_invoice, inv.po.no_po)
    inv.email_job = job
    inv.save()
    return views.get_invoice_by_id(request=request,
                                   id=id_inv,
                                   need_approval=False,
                                   resubmit_invoice=True)