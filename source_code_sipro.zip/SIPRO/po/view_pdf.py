import os
from django.http import HttpResponse
from django.conf import settings
from django.template.loader import get_template
from xhtml2pdf import pisa
from . import views
from main.models import *
from django.contrib.staticfiles import finders


def link_callback(uri, rel):
    """
    Convert HTML URIs to absolute system paths so xhtml2pdf can access those
    resources
    """
    result = finders.find(uri)
    if result:
        if not isinstance(result, (list, tuple)):
            result = [result]
        result = list(os.path.realpath(path) for path in result)
        path = result[0]
    else:
        sUrl = settings.STATIC_URL        # Typically /static/
        sRoot = settings.STATIC_ROOT      # Typically /home/userX/project_static/
        mUrl = settings.MEDIA_URL         # Typically /media/
        mRoot = settings.MEDIA_ROOT       # Typically /home/userX/project_static/media/

        if uri.startswith(mUrl):
            path = os.path.join(mRoot, uri.replace(mUrl, ""))
        elif uri.startswith(sUrl):
            path = os.path.join(sRoot, uri.replace(sUrl, ""))
        else:
            return uri

    # make sure that file exists
    if not os.path.isfile(path):
        raise Exception(
            'media URI must start with %s or %s' % (sUrl, mUrl)
        )
    return path


def render_pdf_view(request, id):
        po = Purchase_Order.objects.get(id=id)
        pr = Purchase_Request.objects.get(id=po.pr_id)
        arguments = {
        "po": po,
        }
        ## for Sitebased template
        if(pr.form_type == 1):
                Sitebased_obj, list_item = views.get_item_sitebased(pr.id)
                arguments['sitebased'] = Sitebased_obj
                arguments['list_item'] = list_item
                template_path = 'templates_po_sitebased.html'
        ## for Workbased template
        elif(pr.form_type == 2):
                workbased_info,list_order= views.get_workbased(pr.id)
                arguments["workbased_info"] = workbased_info
                arguments["list_order"] = list_order
                template_path = "templates_po_workbased.html"
        ## for Timebased template
        else:
                list_item= views.get_timebased(pr.id)
                arguments["list_item"] = list_item
                template_path = "templates_po_timebased.html"
        context = arguments
        # Create a Django response object, and specify content_type as pdf
        response = HttpResponse(content_type='application/pdf')
        # response['Content-Disposition'] = 'attachment; filename="report.pdf"'
        # find the template and render it.
        template = get_template(template_path)
        html = template.render(context)

        # create a pdf
        pisa_status = pisa.CreatePDF(
                html, dest=response, link_callback=link_callback)
        # if error then show some funy view
        if pisa_status.err:
                return HttpResponse('We had some errors <pre>' + html + '</pre>')
        return response
