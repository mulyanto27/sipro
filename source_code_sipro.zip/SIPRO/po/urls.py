from django.urls import path

from . import views
from . import views_approval
from . import view_pdf

app_name = "po"
urlpatterns = [
    path('', views.view_all_po, name='view_all_po'),
    path('select-pr/<slug:id_pr>', views.select_pr, name='select_pr'),
    path('create-po/sitebased/<slug:id_pr>', views.create_po_sitebased, name='create_po_sitebased'),
    path('create-po/timebased/<slug:id_pr>', views.create_po_timebased, name='create_po_timebased'),
    path('create-po/workbased/<slug:id_pr>', views.create_po_workbased, name='create_po_workbased'),

    path('edit-po/timebased/<slug:id>', views.edit_po_timebased, name='edit_po_timebased'),
    path('edit-item-timebased/<slug:id_komponen>/', views.edit_item_timebased, name='edit_item_timebased'),
    path('delete-item-timebased/<slug:id_komponen>/', views.delete_item_timebased, name='delete_item_timebased'),
    path('add-item-timebased/<slug:id>/', views.add_item_timebased, name='add_item_timebased'),

    path('edit-po/workbased/<slug:id>', views.edit_po_workbased, name='edit_po_workbased'),
    path('edit-item-workbased/<slug:id_item>/', views.edit_item_workbased, name='edit_item_workbased'),
    path('delete-item-workbased/<slug:id_item>/', views.delete_item_workbased, name='delete_item_workbased'),
    path('add-item-workbased/<slug:id>/', views.add_item_workbased, name='add_item_workbased'),
    

    path('edit-po/sitebased/<slug:id>', views.edit_po_sitebased, name='edit_po_sitebased'),
    path('edit-item-sitebased/<slug:id_item>/', views.edit_item_sitebased, name='edit_item_sitebased'),
    path('delete-item-sitebased/<slug:id_item>/', views.delete_item_sitebased, name='delete_item_sitebased'),
    path('add-item-sitebased/<slug:id>/', views.add_item_sitebased, name='add_item_sitebased'),
    path('cancel/<slug:id>/', views.cancel_po, name="cancel_po"),
    path('need-approval', views_approval.view_all_approval, name="view_all_approval"),
    path('rejected', views_approval.view_all_rejected_po, name="view_all_rejected"),
    path('active', views.view_active_po, name="view_active_po"),
    path('approve-pm/<slug:id>/', views_approval.approve_po_by_pm, name="approve_po_by_pm"),
    path('approve-hobd/<slug:id>/', views_approval.approve_po_by_hobd, name="approve_po_by_hobd"),
    path('feedbacks/<int:id_subkon>/create', views.create_feedback, name='create_feedback'),
    path('reject-po/<slug:id>/', views_approval.view_reject_po, name="reject_po"),
    path('generate-pdf/<slug:id>/', view_pdf.render_pdf_view, name='generate_pdf'),
    path('<str:tab>/<str:name>', views.dashboard_po, name='dashboard_po'),
    path('<slug:id>', views.get_po_by_id, name='get_po_by_id'),
]