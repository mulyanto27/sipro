from django.shortcuts import render
from main.models import *
from django.core.mail import send_mail
from . import views

"""Views for get need approval po by PM"""
def po_need_approval_pm(pm_id):
    list_need_approval_pm = Purchase_Order.objects.filter(status=1,
                                                          pm__user_id=pm_id).order_by('id')
    return list_need_approval_pm

"""Views for get need approval po by PM"""
def po_need_approval_hobd():
    list_need_approval_hobd = Purchase_Order.objects.filter(status=2).order_by('id')
    return list_need_approval_hobd

"""Views for get all need approval po list"""
def view_all_approval(request):
    user_id = request.session['user_id']
    user = User.objects.get(user_id=user_id)
    if (user.role.id == 5):
        list_need_approval = po_need_approval_pm(user.user_id)
    if (user.role.id == 4):
        list_need_approval = po_need_approval_hobd()
    arg = {'list_need_approval': list_need_approval}
    return render(request, "po_need_approval.html", arg)


"""Views for  approve by PM"""
def approve_po_by_pm(request,id):
    po = Purchase_Order.objects.get(id=id)
    try:
        po.status = 2
        po.feedback = ""
        po.save()
        set_approve_status_job(po.email_job.id)
        send_email(po.hobd.user.email, po.no_po)
        job = setup_deadline(po.hobd.user.email, po.no_po)
        po.email_job = job
        po.save()
        return views.get_po_by_id(request,id,successApprove=True)
    except:
        return views.get_po_by_id(request,id,errorUpdateStatus=True)


"""Views for  approve by HOBD"""
def approve_po_by_hobd(request,id):
    po = Purchase_Order.objects.get(id=id)
    try:
        po.status = 3
        po.feedback = ""
        po.save()
        set_approve_status_job(po.email_job.id)
        return views.get_po_by_id(request,id,successApprove=True)
    except:
        return views.get_po_by_id(request,id,errorUpdateStatus=True)


def set_approve_status_job(worker_id):
    job = Worker_Email_Job.objects.get(id=worker_id)
    job.approval_status = "APPROVED"
    job.save()


def setup_deadline(email_des, no_po):
    body = "Anda perlu menyetujui Purchase Order "+ no_po +" melalui link berikut http://cashpoint.citius.co.id/po/need-approval"
    job = Worker_Email_Job(
        subject="[Info] Need your approval for purchase order",
        message=body,
        email_des=email_des,
        approval_status="WAITING APPROVAL")
    job.save()
    return job


def send_email(email_des, no_po):
    message = "Anda perlu menyetujui Purchase Order "+ no_po +" melalui link berikut http://cashpoint.citius.co.id/po/need-approval"
    send_mail( 
        "[Info] Need Approval for Purchase Order "+no_po, 
        message, 
        "citius.sipro@gmail.com", [email_des], False)


"""Views for reject po by pm"""
def reject_po_by_pm(request, id, feedback):
    po = Purchase_Order.objects.get(id=id)
    po.feedback = feedback
    po.status = 6
    po.save()
    set_reject_status_job(po.email_job.id)

"""Views for reject po by hobd"""
def reject_po_by_hobd(request, id, feedback):
    po = Purchase_Order.objects.get(id=id)
    po.feedback = feedback
    po.status = 7
    po.save()
    set_reject_status_job(po.email_job.id)


def view_reject_po(request, id):
    feedback = request.POST['feedback-input']
    role_id = request.session['role_id']
    user_id = request.session['user_id']

    po = Purchase_Order.objects.get(id=id)
    
    if(role_id==5):
        try:
            reject_po_by_pm(request,id, feedback)
            return views.get_po_by_id(request,id,successReject=True)
        except:
            return views.get_po_by_id(request,id,errorUpdateStatus=True)
    elif(role_id==4):
        try:
            reject_po_by_hobd(request,id, feedback)
            return views.get_po_by_id(request,id,successReject=True)
        except:
            return views.get_po_by_id(request,id,errorUpdateStatus=True)
    

def set_reject_status_job(worker_id):
    job = Worker_Email_Job.objects.get(id=worker_id)
    job.approval_status = "REJECTED"
    job.save()

"""Views for get all rejected po list"""
def get_all_po_rejected():
    list_rejected_po = Purchase_Order.objects.filter(status__in=(6,7)).order_by('id')
    return list_rejected_po

def view_all_rejected_po(request):
    list_rejected_po = get_all_po_rejected()
    arg = {'list_rejected_po': list_rejected_po}
    return render(request, "po_rejected.html", arg)