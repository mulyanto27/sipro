from django.db.models.fields import DecimalField
from django.http.response import HttpResponse, HttpResponseForbidden, HttpResponseNotFound, HttpResponseServerError, JsonResponse
from django.shortcuts import redirect, render
from django.core.mail import send_mail
from main.views import handle_403_page, handle_404_page, handle_500_page
from main.models import *
from . import view_pdf
import decimal
import datetime

"""Views for getting all PO"""
def view_all_po(request, message = None):
    #get all Purchase Order
    id_role_user = request.session['role_id']
    id_user = request.session['user_id']
    argument = {}
    list_po = []
    if id_role_user == 8:
        try:
            subkon = Subkontraktor.objects.get(user_id = id_user)
            data_subkon_id = subkon.data_subkontraktor.id
            list_po = Purchase_Order.objects.filter(data_subkontraktor__id=data_subkon_id, status__in=[3,4]).order_by('id')
            argument["page_title"] = subkon.data_subkontraktor.vendor_name
        except:
            return handle_500_page(request, HttpResponseServerError)
    else:
        list_po = Purchase_Order.objects.all().order_by('id')

    argument["list_po"] = list_po
    return render(request, 'list_all_po.html', argument)

"""Views for getting active PO"""
def view_active_po(request):
    #get all Purchase Order
    list_actived_po = Purchase_Order.objects.filter(status=3).order_by('id')
    argument = {
        'list_actived_po': list_actived_po,
    }
    return render(request, 'po_active.html', argument)

"""Views for getting PO by id"""
def get_po_by_id(request, id, successApprove=False,successReject=False,successCreatePO=False,
                    successCreateVendorEvaluation=False,errorUpdateStatus=False, successCancel=False):
    #get detail data for each Purchase Order
    selected_po = Purchase_Order.objects.get(id=id)
    vendor = Data_Subkontraktor.objects.get(id=selected_po.data_subkontraktor_id)
    category = Category.objects.get(id=selected_po.category_id)

    #List for authorize button edit
    list_status_edit= [3,6,7]

    #get PR Object Reference
    selected_pr = Purchase_Request.objects.get(id=selected_po.pr_id)
    id_form_type = selected_pr.form_type


    #get all invoice that related to this PO
    list_invoice = Invoice.objects.filter(po_id=id).order_by('id')

    #check status and convert to detail status
    status_int = selected_po.status
    switcher = {
        1: "Waiting Approval PM",
        2: "Waiting Approval Head of Business Delivery",
        3: "Active",
        4: "Closed",
        5: "Cancelled",
        6: "Rejected by PM",
        7: "Rejected by Head of Business Delivery"
    }
    status = switcher.get(status_int, "Revised by PM")

    #Dictionary to pass object to template
    arguments = {
            'successApprove':successApprove,
            'successReject':successReject,
            'successCreatePO':successCreatePO,
            'successCancel':successCancel,
            'po': selected_po,
            'pr': selected_pr,
            'vendor': vendor,
            'list_invoice': list_invoice,
            'category': category,
            'status': status,
            'grand_total_price':selected_po.grand_total_price,
            'list_status_edit':list_status_edit, 
            'successCreateVendorEvaluation':successCreateVendorEvaluation,
            'errorUpdateStatus':errorUpdateStatus,
    }
    ##Supplier performance per PO
    try:
        performa = Performa_Subkontraktor.objects.get(po=selected_po)
        arguments['performa']=performa
    except:
        print("Performa Subkontraktor for PO Nomor: "+selected_po.no_po)
    ##get all item for each PO
    #get item for Timebased category
    if (id_form_type == 3):
        list_item = get_timebased(selected_pr.id)
        arguments['list_item']=list_item
        return render(request, "detail_po_timebased.html", arguments)
    
    #get item for Sitebased Category
    elif (id_form_type == 1):
        Sitebased_obj,list_item = get_item_sitebased(selected_po.pr_id)
        arguments['sitebased']=Sitebased_obj
        arguments['list_item']= list_item
        return render(request, "detail_po_sitebased.html", arguments)

    #get item for Workbased Category
    elif (id_form_type == 2):
        Workbased_obj,list_row_site = get_workbased(selected_po.pr_id)
        arguments['workbased']=Workbased_obj
        arguments['list_row_site']= list_row_site
        return render(request, "detail_po_workbased.html", arguments)

"""Views for select pr"""
def select_pr(request,id_pr):
    #get PR object for PO
    pr = Purchase_Request.objects.get(id=id_pr)

    #Find category to direct appropriate views
    id_form_type = pr.form_type
    if id_form_type == 3:
        return redirect('po:create_po_timebased',id_pr=id_pr)
    elif id_form_type == 1:
        return redirect('po:create_po_sitebased',id_pr=id_pr)
    elif id_form_type == 2:
        return redirect('po:create_po_workbased',id_pr=id_pr)


"""Views for Create PO Timebased"""
def create_po_timebased(request,id_pr):
    #get PR and Category Object for reference
    pr = Purchase_Request.objects.get(id=id_pr)
    id_category = pr.category_id
    category = Category.objects.get(id=id_category)
    vendor = Data_Subkontraktor.objects.get(id=pr.data_subkontraktor_id)

    #define temp variable for grand_total_price 
    total_harga = 0
   
    #get item of PR
    list_item = get_timebased(id_pr)

    #Generate PO Number
    generated_no_po = generateNoPO()
    
    #Dictionary to pass objects to template
    arguments = {
        'pr': pr,
        'no_po': generated_no_po,
        'vendor': vendor,
        'category': category,
        'list_item': list_item,
    }
    #Retrieve all input and saving new PO
    if request.method == "POST":
        datecreate = request.POST['datecreate']
        notes = request.POST['notes']
        terms_of_pay = request.POST['terms_of_pay']
        hobd= User.objects.get(role=4)

        #Send and setup deadline
        send_email(pr.pm.user.email, generated_no_po)
        email_job = setup_deadline_pm(pr.pm.user.email, generated_no_po)

        #Create new PO
        po = Purchase_Order.objects.create(no_po=generated_no_po,pr=pr,pm=pr.pm,hobd=hobd,category=category,
                                data_subkontraktor=vendor,date_created=datecreate,status=1,notes =notes,
                                terms_of_payment=terms_of_pay,email_job=email_job,outstanding_po=100,
                                status_revision = 0)
        try:
            po.save()
            arguments['status']="Waiting Approval PM"
            arguments['successCreatePO']=True

        except Exception as e:
            arguments['errorSavingPO'] = True
            return render(request, "create_po_timebased.html", arguments)
        
        #Get unit price and discount input
        list_unit_price = request.POST.getlist("unit_price")
        list_discount = request.POST.getlist("discount")
        
        #Save timebased attribute
        for i in range(len(list_item)):
            timebased = list_item[i]
            timebased.unit_price = list_unit_price[i]
            timebased.discount = list_discount[i]
            try:
                timebased.save()
                total_harga += timebased.total_price
                
            except:
                 arguments['errorSavingItemTimebased'] = True
                 return render(request, "create_po_timebased.html", arguments)

        #Update komponen that related to this PO
        for item in list_item:
            Komponen.objects.filter(id=item.komponen_id).update(po=po)
        

        #Update grand_total_price PO
        updateGrandTotalPO(po.id,total_harga)

        #Update status PR
        Purchase_Request.objects.filter(id=id_pr).update(status=1)

        return get_po_by_id(request,id=po.id,successCreatePO=True)
    return render(request,"create_po_timebased.html",arguments)

    
"""Views for get komponen timebased"""
def get_timebased(id_pr):
    list_item = []
    list_komponen = Komponen.objects.filter(pr_id=id_pr).order_by('id')
    for komponen in list_komponen:
        list_item.append(Timebased.objects.get(komponen_id=komponen.id))
    return list_item


# SITEBASED
def create_po_sitebased(request, id_pr, message = None):
    #Get PR and Category Object for Reference
    pr = Purchase_Request.objects.get(id=id_pr)
    id_category = pr.category_id
    category= Category.objects.get(id=id_category)
    vendor = Data_Subkontraktor.objects.get(id=pr.data_subkontraktor_id)

    #define temp variable for grand_total_price
    total_harga = 0

    #generate No PO
    generated_no_po = generateNoPO()

    #Get Sitebased and list item
    Sitebased_obj,list_item_sitebased = get_item_sitebased(id_pr)

    arguments = {
        'pr': pr,
        'no_po': generated_no_po,
        'vendor': vendor,
        'category': category,
        'sitebased':Sitebased_obj,
        'list_item':list_item_sitebased,

    }
    #Retrieve all input and saving new PO
    if request.method == "POST":
        datecreate = request.POST['datecreate']
        notes = request.POST['notes']
        terms_of_pay = request.POST['terms_of_pay']
        hobd= User.objects.get(role=4)

        #Send and setup deadline
        send_email(pr.pm.user.email, generated_no_po)
        email_job = setup_deadline_pm(pr.pm.user.email, generated_no_po)

        #Create new PO
        po = Purchase_Order.objects.create(no_po=generated_no_po,pr=pr,pm=pr.pm,hobd=hobd,category=category,
                                data_subkontraktor=vendor,date_created=datecreate,status=1,notes =notes,
                                terms_of_payment=terms_of_pay,email_job=email_job,outstanding_po=100,
                                status_revision = 0)
        try:
            po.save()
            arguments['status']="Waiting Approval PM"
            arguments['successCreatePO']=True
        #if error when saving PO
        except Exception as e:
            arguments['errorSavingPO'] = True
            return render(request, "create_po_sitebased.html", arguments)
        
      
        #Get unit price and discount input
        list_unit_price = request.POST.getlist("unit_price")
        list_discount = request.POST.getlist("discount")

        #Update unit price and discount per item and saving item
        for i in range(len(list_item_sitebased)):
            item = list_item_sitebased[i]
            item.unit_price = list_unit_price[i]
            item.discount = list_discount[i]
            try:
                item.save()
                total_harga += item.total_price
                
            except:
                 arguments['errorSavingItemSitebased'] = True
                 return render(request, "create_po_sitebased.html", arguments)
        
        #Update komponen that related to this PO
        Komponen.objects.filter(pr_id=id_pr).update(po=po)

        #Update grand_total_price PO
        updateGrandTotalPO(po.id,total_harga)

        #Update status PR
        Purchase_Request.objects.filter(id=id_pr).update(status=1)
        
        return get_po_by_id(request,id=po.id,successCreatePO=True)
    return render(request, "create_po_sitebased.html", arguments)


def get_item_sitebased(id_pr):
    Komponen_obj = Komponen.objects.get(pr_id=id_pr)
    Sitebased_obj = Sitebased.objects.get(komponen_id = Komponen_obj.id)
    list_item_sitebased = Item_Sitebased.objects.filter(sitebased = Sitebased_obj)
    return Sitebased_obj, list_item_sitebased



"""Views for Create PO Workbased"""
def create_po_workbased(request,id_pr):
    #get PR and Category Object for reference
    pr = Purchase_Request.objects.get(id=id_pr)
    id_category = pr.category_id
    category = Category.objects.get(id=id_category)
    vendor = Data_Subkontraktor.objects.get(id=pr.data_subkontraktor_id)

    #define temp variable for grand_total_price
    total_harga = 0

    #Get workbased object and their site
    Workbased_obj,list_row_site = get_workbased(id_pr)
    
    #Generate PO Number
    generated_no_po = generateNoPO()

    #Dictionary to pass objects to template
    arguments = {
            'pr': pr,
            'no_po': generated_no_po,
            'vendor': vendor,
            'category': category,
            'list_row_site': list_row_site,
            'workbased':Workbased_obj,
    }
    
    #Retrieve all input and saving new PO
    if request.method == "POST":
        datecreate = request.POST['datecreate']
        notes = request.POST['notes']
        terms_of_pay = request.POST['terms_of_pay']
        hobd= User.objects.get(role=4)

        #Send and setup deadline
        send_email(pr.pm.user.email, generated_no_po)
        email_job = setup_deadline_pm(pr.pm.user.email, generated_no_po)

        #Create new PO
        po = Purchase_Order.objects.create(no_po=generated_no_po,pr=pr,pm=pr.pm,hobd=hobd,category=category,
                                data_subkontraktor=vendor,date_created=datecreate,status=1,notes =notes,
                                terms_of_payment=terms_of_pay,email_job=email_job,outstanding_po=100,
                                status_revision = 0)
        try:
            po.save()
            arguments['status']="Waiting Approval PM"
            arguments['successCreatePO']=True
        #if error when saving PO
        except Exception as e:
            arguments['errorSavingPO'] = True
            return render(request, "create_po_workbased.html", arguments)
        
        #Get unit price and discount input
        list_unit_price = request.POST.getlist("unit_price")
        list_discount = request.POST.getlist("discount")

        #Save workbased attribute
        for i in range(len(list_row_site)):
            site = list_row_site[i]
            site.unit_price = list_unit_price[i]
            site.discount = list_discount[i]
            try:
                site.save()
                total_harga += site.total_price
                
            except:
                 arguments['errorSavingItemWorkbased'] = True
                 return render(request, "create_po_workbased.html", arguments)
        
        #Update komponen that related to this PO
        Komponen.objects.filter(pr_id=id_pr).update(po=po)


        #Update grand_total_price PO
        updateGrandTotalPO(po.id,total_harga)

        #Update status PR
        Purchase_Request.objects.filter(id=id_pr).update(status=1)

        return get_po_by_id(request,id=po.id,successCreatePO=True)
    return render(request,"create_po_workbased.html",arguments)


"""Views for get komponen workbased"""
def get_workbased(id_pr):
    Komponen_obj = Komponen.objects.get(pr_id=id_pr)
    Workbased_obj = Workbased.objects.get(komponen_id = Komponen_obj.id)
    list_row_site = Item_Workbased.objects.filter(workbased_id=Workbased_obj.komponen_id)
    return Workbased_obj, list_row_site


"""Views for edit PO Timebased"""
def edit_po_timebased(request,id,errorAddItem = False):
    #get detail data for each Purchase Order
    po = Purchase_Order.objects.get(id=id)

    #get PR Object Reference
    pr = Purchase_Request.objects.get(id=po.pr_id)
    vendor = Data_Subkontraktor.objects.get(id=po.data_subkontraktor_id)
    category = Category.objects.get(id=po.category_id)

    #define temp variable for grand_total_price
    total_harga = 0

    #get item timebased
    list_item = get_timebased(pr.id)
    
    ## get all vendor which has correct category
    all_appropriate_vendor = get_related_vendor(pr.category.id)
    all_appropriate_vendor.remove(Data_Subkontraktor.objects.get(id=pr.data_subkontraktor.id))
 
    ## get all projects
    all_projects = Project.objects.exclude(id=pr.project.id).order_by('name')

    ## get all areas
    all_areas = Area.objects.exclude(id=pr.area.id).order_by('name')

    arguments={
        'po':po,
        'pr':pr,
        'list_item':list_item,
        'vendor':vendor,
        'category':category,
        'errorAddItem':errorAddItem,
        'all_vendor':all_appropriate_vendor,
        'all_projects':all_projects,
        'all_areas': all_areas,
    }
    #Retrieve all input
    if request.method == "POST":
        project = request.POST['project']
        area = request.POST['area']
        vendor = request.POST['vendor']
        datecreate = request.POST['datecreate']
        notes = request.POST['notes']
        terms_of_pay = request.POST['terms_of_pay']

        try:
            #Update project,area, vendor to related pr
            pr.project = Project.objects.get(id = project)
            pr.area = Area.objects.get(id = area)
            pr.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
            pr.save()

            #Update notes, terms of payment, supplier, and date to related po
            po.notes = notes
            po.terms_of_payment = terms_of_pay
            po.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
            po.date_created = datecreate

            #Update po status_revision to revision if po status is active
            if (po.status == 3 ):
                po.status_revision = 1
            
            #Update po status to waiting approval
            po.status = 1

            #Set and send email to approval
            send_email(pr.pm.user.email, po.no_po)
            email_job = setup_deadline_pm(pr.pm.user.email, po.no_po)
            po.email_job = email_job

            #Update grand total price
            list_item=get_timebased(pr.id)
            for item in list_item:
                total_harga = item.total_price
            po.save()   
            updateGrandTotalPO(id, total_harga)
            return redirect('po:get_po_by_id',id)
        except Exception as e:
            arguments['errorEditingPO'] = True
            return render(request, "edit_po_timebased.html", arguments)
    return render(request,"edit_po_timebased.html",arguments)

"""Views for adding komponen/item timebased"""
def add_item_timebased(request, id):
    arguments = {}
    po= Purchase_Order.objects.get(id=id)
    if request.method == "POST":
        item = request.POST['item']
        item_detail = request.POST["item_detail"]
        start_date = request.POST["start_date"]
        end_date = request.POST["end_date"]
        period = request.POST["period"]
        quantity = request.POST["quantity"]
        unit_price = request.POST["unit_price"]
        discount = request.POST["discount"]

        try:
            new_komponen = Komponen.objects.create(pr=po.pr)
            new_komponen.po = po
            new_komponen.save()
        except:
            return edit_po_timebased(request, id, errorAddItem=True)
        try:
            new_timebased = Timebased.objects.create(
                komponen=new_komponen, item=item, item_detail=item_detail, start_date=start_date, 
                end_date=end_date,period=period, quantity=quantity,unit_price=unit_price,discount=discount
            )
        except:
            new_komponen.delete()
            return edit_po_timebased(request, id, errorAddItem=True)
        return redirect('po:edit_po_timebased', id = id)

"""Views for deleting komponen timebased"""
def delete_item_timebased(request, id_komponen):
    komponen = Komponen.objects.get(id=id_komponen)
    response_data = {}
    if request.POST.get('action') == 'post':
        komponen.delete()
        response_data["del_status"] = "Success delete the order"
        return JsonResponse(response_data)

"""Views for editing item/komponen timebased"""
def edit_item_timebased(request, id_komponen):
    timebased = Timebased.objects.get(komponen__id=id_komponen)
    po = Purchase_Order.objects.get(id=timebased.komponen.po.id)
    arguments = {"obj_timebased": timebased,"po":po}
    if request.method == "POST":
        item = request.POST['item']
        item_detail = request.POST["item_detail"]
        start_date = request.POST["start_date"]
        end_date = request.POST["end_date"]
        period = request.POST["period"]
        quantity = request.POST["quantity"]
        unit_price = request.POST["unit_price"]
        discount = request.POST["discount"]

        timebased.item = item
        timebased.item_detail = item_detail
        timebased.start_date = start_date
        timebased.end_date = end_date
        timebased.period = period
        timebased.quantity = quantity
        timebased.unit_price= unit_price
        timebased.discount= discount
        try:
            timebased.save()
        except:
            arguments["errorUpdate"] = True
            return render(request, "edit_item_timebased.html", arguments)
        return redirect("po:edit_po_timebased", po.id)
    return render(request,"edit_item_timebased.html", arguments)
    

"""Views for edit PO Workbased"""
def edit_po_workbased(request,id,errorAddItem = False):
    #get detail data for each Purchase Order
    po = Purchase_Order.objects.get(id=id)

    #get PR Object Reference
    pr = Purchase_Request.objects.get(id=po.pr_id)
    vendor = Data_Subkontraktor.objects.get(id=po.data_subkontraktor_id)
    category = Category.objects.get(id=po.category_id)

    #define temp variable for grand_total_price
    total_harga = 0

    #Get workbased object and their site
    Workbased_obj,list_row_site = get_workbased(pr.id)

    ## get all vendor which has correct category
    all_appropriate_vendor = get_related_vendor(pr.category.id)
    all_appropriate_vendor.remove(Data_Subkontraktor.objects.get(id=pr.data_subkontraktor.id))
 
    ## get all projects
    all_projects = Project.objects.exclude(id=pr.project.id).order_by('name')

    ## get all areas
    all_areas = Area.objects.exclude(id=pr.area.id).order_by('name')

    #Dictionary to pass objects to templates
    arguments = {
        'pr': pr,
        'po':po,
        'vendor': vendor,
        'category': category,
        'list_row_site': list_row_site,
        'workbased':Workbased_obj,
        'errorAddItem':errorAddItem,
        'all_vendor':all_appropriate_vendor,
        'all_projects':all_projects,
        'all_areas': all_areas,
    }
    #Retrieve all input
    if request.method == "POST":
        project = request.POST['project']
        area = request.POST['area']
        vendor = request.POST['vendor']
        datecreate = request.POST['datecreate']
        sow = request.POST['sow']
        description = request.POST['description']
        notes = request.POST['notes']
        terms_of_pay = request.POST['terms_of_pay']

        try:
            #Update project,area, vendor to related pr
            pr.project = Project.objects.get(id = project)
            pr.area = Area.objects.get(id = area)
            pr.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
            pr.save()
            
            #Update Sitebased object
            Workbased_obj.sow = sow
            Workbased_obj.description = description
            Workbased_obj.save()

            po.notes = notes
            po.terms_of_payment = terms_of_pay
            po.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
            po.date_created = datecreate

            #Update po status_revision to revision if po status is active
            if (po.status == 3 ):
                po.status_revision = 1
            
            #Update po status to waiting approval
            po.status = 1

            #Set and send email to approval
            send_email(pr.pm.user.email, po.no_po)
            email_job = setup_deadline_pm(pr.pm.user.email, po.no_po)
            po.email_job = email_job

            Workbased_obj,list_row_site= get_workbased(pr.id)
            #Update grand total price in PO
            for site in list_row_site:
                total_harga += site.total_price
            po.save()
            updateGrandTotalPO(id, total_harga)
            return redirect('po:get_po_by_id',id)
        except Exception as e:
            arguments['errorEditingPO'] = True
            return render(request, "edit_po_workbased.html", arguments)
    return render(request,"edit_po_workbased.html",arguments)

"""View for Editing Item Workbased"""
def edit_item_workbased(request,id_item):
    item_workbased = Item_Workbased.objects.get(id=id_item)
    pr = Purchase_Request.objects.get(id=item_workbased.workbased.komponen.pr.id)
    po = Purchase_Order.objects.get(id=item_workbased.workbased.komponen.po.id)
    arguments = {
        'pr': pr,
        'po':po,
        'item_workbased':item_workbased
    }
    if request.method == "POST":
        sow = request.POST['sow']
        quantity = request.POST['quantity']
        unit_price = request.POST['unit_price']
        discount = request.POST['discount']

        # Edit attribute item_sitebased
        item_workbased.sow = sow
        item_workbased.quantity = quantity
        item_workbased.unit_price = unit_price
        item_workbased.discount = discount
        try:
            item_workbased.save()
        except:
            arguments["errorUpdate"] = True
            return render(request, "edit_item_workbased.html", arguments)
        return redirect("po:edit_po_workbased", id=po.id)
    return render(request,"edit_item_workbased.html", arguments)

"""View for Adding Item Workbased"""
def add_item_workbased(request, id):
    arguments={}
    selected_workbased = Workbased.objects.get(komponen__po__id=id)
    if request.method == "POST":
        site_id = request.POST["site_id"]
        site_name = request.POST["site_name"]
        quantity = request.POST["quantity"]
        unit_price = request.POST["unit_price"]
        discount = request.POST["discount"]

        try:
            new_item_workbased = Item_Workbased.objects.create(
                workbased=selected_workbased, site_id=site_id, site_name=site_name, quantity=quantity,
                unit_price=unit_price, discount=discount
            )
        except:
            return edit_po_workbased(request, id, errorAddItem=True)
        return redirect('po:edit_po_workbased', id = id)
        
"""Views for deleting item workbased"""
def delete_item_workbased(request, id_item):
    response_data = {}
    item_workbased = Item_Workbased.objects.get(id=id_item)
    if request.POST.get('action') == 'post':
        item_workbased.delete()
        response_data["del_status"] = "Success delete the item"
        return JsonResponse(response_data)

"""Views for edit PO Sitebased"""
def edit_po_sitebased(request,id,errorAddItem=False):
    #get detail data for each Purchase Order
    po = Purchase_Order.objects.get(id=id)

    #get PR Object Reference
    pr = Purchase_Request.objects.get(id=po.pr_id)
    vendor = Data_Subkontraktor.objects.get(id=po.data_subkontraktor_id)
    category = Category.objects.get(id=po.category_id)

    #define temp variable for grand_total_price
    total_harga = 0

    #Get Sitebased and list item
    Sitebased_obj,list_item_sitebased = get_item_sitebased(pr.id)

    ## get all vendor which has correct category
    all_appropriate_vendor = get_related_vendor(pr.category.id)
    all_appropriate_vendor.remove(Data_Subkontraktor.objects.get(id=pr.data_subkontraktor.id))
 
    ## get all projects
    all_projects = Project.objects.exclude(id=pr.project.id).order_by('name')

    ## get all areas
    all_areas = Area.objects.exclude(id=pr.area.id).order_by('name')
   
    arguments = {
        'pr': pr,
        'po':po,
        'vendor': vendor,
        'category': category,
        'sitebased':Sitebased_obj,
        'list_item': list_item_sitebased,
        'errorAddItem':errorAddItem,
        'all_vendor':all_appropriate_vendor,
        'all_projects':all_projects,
        'all_areas': all_areas,
    }
    #Retrieve all input
    if request.method == "POST":
        project = request.POST['project']
        area = request.POST['area']
        vendor = request.POST['vendor']
        datecreate = request.POST['datecreate']
        site_id = request.POST['site_id']
        site_name = request.POST['site_name']
        description = request.POST['description']
        notes = request.POST['notes']
        terms_of_pay = request.POST['terms_of_pay']

        try:

            #Update project,area, vendor to related pr
            pr.project = Project.objects.get(id = project)
            pr.area = Area.objects.get(id = area)
            pr.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
            pr.save()

            #Update Sitebased object
            Sitebased_obj.site_id = site_id
            Sitebased_obj.site_name = site_name
            Sitebased_obj.description = description
            Sitebased_obj.save()

            #Update PO
            po.notes = notes
            po.terms_of_payment = terms_of_pay
            po.data_subkontraktor = Data_Subkontraktor.objects.get(id=vendor)
            po.date_created = datecreate

            #Update po status_revision to revision if po status is active
            if (po.status == 3 ):
                po.status_revision = 1
            
            #Update po status to waiting approval
            po.status = 1

            #Set and send email to approval
            send_email(pr.pm.user.email, po.no_po)
            email_job = setup_deadline_pm(pr.pm.user.email, po.no_po)
            po.email_job = email_job

            Sitebased_obj,list_item_sitebased= get_item_sitebased(pr.id)
            for item in list_item_sitebased:
                total_harga += item.total_price
            po.save()
            updateGrandTotalPO(id, total_harga)
            arguments["sitebased"] = Sitebased_obj
            arguments["list_item"] = list_item_sitebased
            return redirect('po:get_po_by_id',id)
        except Exception as e:
            arguments['errorEditingPO'] = True
            return render(request, "edit_po_sitebased.html", arguments)
    return render(request,"edit_po_sitebased.html",arguments)
    

"""View for Editing Item Sitebased"""
def edit_item_sitebased(request,id_item):
    item_sitebased = Item_Sitebased.objects.get(id=id_item)
    pr = Purchase_Request.objects.get(id=item_sitebased.sitebased.komponen.pr.id)
    po = Purchase_Order.objects.get(id=item_sitebased.sitebased.komponen.po.id)
    arguments = {
        'pr': pr,
        'po':po,
        'item_sitebased':item_sitebased
    }
    if request.method == "POST":
        sow = request.POST['sow']
        quantity = request.POST['quantity']
        unit_price = request.POST['unit_price']
        discount = request.POST['discount']

        # Edit attribute item_sitebased
        item_sitebased.sow = sow
        item_sitebased.quantity = quantity
        item_sitebased.unit_price = unit_price
        item_sitebased.discount = discount
        try:
            item_sitebased.save()
        except:
            arguments["errorUpdate"] = True
            return render(request, "edit_item_sitebased.html", arguments)
        return redirect("po:edit_po_sitebased", id=po.id)
    return render(request,"edit_item_sitebased.html", arguments)

"""Views for deleting item sitebased"""
def delete_item_sitebased(request, id_item):
    response_data = {}
    item_sitebased = Item_Sitebased.objects.get(id=id_item)
    if request.POST.get('action') == 'post':
        item_sitebased.delete()
        response_data["del_status"] = "Success delete the item"
        return JsonResponse(response_data)

"""Views for adding komponen/object Sitebased"""
def add_item_sitebased(request, id):
    arguments = {}
    selected_sitebased = Sitebased.objects.get(komponen__po__id=id)

    if request.method == "POST":
        sow = request.POST["sow"]
        quantity = request.POST["quantity"]
        unit_price = request.POST["unit_price"]
        discount = request.POST["discount"]
        try:
            new_item_sitebased = Item_Sitebased.objects.create(
                sitebased=selected_sitebased, sow=sow, quantity=quantity, unit_price= unit_price,
                discount= discount
            )
        except:
            return edit_po_sitebased(request, id, errorAddItem=True)
        return redirect('po:edit_po_sitebased', id = id)

"""View for Cancelling PO"""
def cancel_po(request,id):
        #get detail data for each Purchase Order
        po = Purchase_Order.objects.get(id=id)

        if request.method == "POST":
            #Retrieve input cancellation reason
            cancel_reason = request.POST['cancel_reason']

            #update status and cancellation reason PO
            po.status = 5
            po.cancellation_reason = cancel_reason
            
            try:
                po.save()
                return get_po_by_id(request, id=po.id,successCancel=True)
            except:
                return get_po_by_id(request, id=po.id,errorUpdateStatus=True)



"""Function for update grand_total_price po"""
def updateGrandTotalPO(id,total_harga):
    po= Purchase_Order.objects.get(id=id)
    po.grand_total_price = total_harga
    po.save()
    grand_total_price = str(po.grand_total_price)
    po.outstanding_grand_total = decimal.Decimal(grand_total_price) - po.total_paid_off_bill 
    po.save()

"""Function for generate PO number"""
def generateNoPO():
    seq_number = get_no_po_sequence_number()
    now = datetime.datetime.now()
    romawi_month = month_to_romawi(now.month)
    res = "{}/PO/CSI/{}/{}".format(seq_number,romawi_month,now.year)
    return res

def get_no_po_sequence_number():
    try:
        latest_po_id = Purchase_Order.objects.latest('id').id
        seq_num = latest_po_id + 1
    except Purchase_Order.DoesNotExist:
        seq_num = 1
    formatted_seq = "{:04d}".format(seq_num%9999)
    return formatted_seq

def month_to_romawi(month):
    month = int(month)
    return {
        1: 'I',
        2: 'II',
        3: 'III',
        4: 'IV',
        5: 'V',
        6: 'VI',
        7: 'VII',
        8: 'VIII',
        9: 'IX',
        10: 'X',
        11: 'XI',
        12: 'XII',
    }[month]

'''Views for all Purchase Order based on Dashboard'''
def dashboard_po(request, tab, name):
    if not (request.session['role_id'] == 8):
        results = {}
        if tab == 'category':
            #get all data about each PO based on its categories
            po_per_category = Purchase_Order.objects\
                .filter(category__category_name=name)\
                .order_by('no_po')
            results['list_po'] = po_per_category
        elif tab == 'project':
            #get all data about each PO based on its project name
            po_per_project = Purchase_Order.objects\
                .filter(pr__project__name=name)\
                .order_by('no_po')
            results['list_po'] = po_per_project
        elif tab == 'area':
            #get all data about each PO based on its area name
            po_per_area = Purchase_Order.objects\
                .filter(pr__area__name=name)\
                .order_by('no_po')
            results['list_po'] = po_per_area
        else:
            return handle_404_page(request, HttpResponseNotFound)
        
        results['tab'] = tab.capitalize()
        results['name'] = name
    else:
        return handle_403_page(request, HttpResponseNotFound)
    return render(request, 'dashboard_po.html', results)
    
"""Function for get related vendor data based on category"""
def get_related_vendor(id_category):
    related_vendors_data = Category_Data_Subkontraktor.objects.filter(category__id = id_category, data_subkontraktor__approval_status = 1).values('data_subkontraktor')
    all_appropriate_vendor = [] # list object Data_Subkontraktor which match the category
    for item in related_vendors_data:
        all_appropriate_vendor.append(Data_Subkontraktor.objects.get(id=item['data_subkontraktor']))
    return all_appropriate_vendor

'''Views for send email'''
def send_email(email_des, no_po):
    message = "Anda perlu menyetujui Purchase Order "+ no_po +" melalui link berikut http://cashpoint.citius.co.id/po/need-approval"
    send_mail( 
        "[Info] Need Approval for Purchase Order "+no_po, 
        message, 
        "citius.sipro@gmail.com", [email_des], False)

'''Views for setup deadline for PM'''
def setup_deadline_pm(email_des, no_po):
    body = "Anda perlu menyetujui Purchase Order "+ no_po +" melalui link berikut http://cashpoint.citius.co.id/po/need-approval"
    job = Worker_Email_Job(
        subject="[Info] Need Approval for Purchase Order "+no_po,
        message=body,
        email_des=email_des,
        approval_status="WAITING APPROVAL")
    job.save()
    return job

def create_feedback(request, id_subkon):
    if request.method == 'POST':
        data_subkon = Data_Subkontraktor.objects.get(id = id_subkon)
        comment = request.POST.get("comment")
        id_po = request.POST.get("id_po")
        po = Purchase_Order.objects.get(id = id_po)
        id_pm = request.POST.get("id_pm")
        pm = User.objects.get(user_id = id_pm)
        performa = Performa_Subkontraktor(comment = comment, pm = pm,po = po, data_subkontraktor = data_subkon  )
        performa.save()
        request.method = 'GET'
        return get_po_by_id(request, id_po, successCreateVendorEvaluation=True)
    else:
        return handle_403_page(request, HttpResponseForbidden)
