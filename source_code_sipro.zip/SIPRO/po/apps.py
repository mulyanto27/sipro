from django.apps import AppConfig


class PoConfig(AppConfig):
    name = 'po'
