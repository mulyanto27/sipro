import logging
from main.models import Job, Worker_Email_Job

from django.conf import settings

from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from django.core.management.base import BaseCommand
from django_apscheduler.jobstores import DjangoJobStore
from django_apscheduler.models import DjangoJobExecution
from datetime import datetime, timedelta
from django.core.mail import send_mail


def send_scheduled_email():
    job_list = Job.objects.filter(status="TODO", sent_at__lt=datetime.now())
    existed_id = set()
    for job in job_list:
        job.status = "SENT"
        if job.email_job_id in existed_id:
            continue
        existed_id.add(job.email_job_id)
        if job.email_job.approval_status not in ("APPROVED","REJECTED"):
            send_mail(
                job.email_job.subject,
                job.email_job.message,
                "citius.sipro@gmail.com", [job.email_job.email_des], False)
            print("job send email : " + job.email_job.email_des)
            date_change = timedelta(days=3)
            if (job.email_job.approval_status=="PENDING"):
                date_change = timedelta(days=7)
            sent_at = job.sent_at + date_change
            new_job = Job(status="TODO",
                          email_job=job.email_job,
                          sent_at=sent_at)
            new_job.save()
        job.save()


def delete_old_job_executions(max_age=604_800):
    """This job deletes all apscheduler job executions older than `max_age` from the database."""
    DjangoJobExecution.objects.delete_old_job_executions(max_age)
    Job.objects.filter(status="SENT", sent_at__lt=datetime.now()-timedelta(days=8)).delete()


class Command(BaseCommand):
    help = "Runs apscheduler."

    def handle(self, *args, **options):
        scheduler = Command.run_worker()

        try:
            scheduler.start()
        except KeyboardInterrupt:
            scheduler.shutdown()
    
    def run_worker():
        scheduler = BlockingScheduler(timezone=settings.TIME_ZONE)
        scheduler.add_jobstore(DjangoJobStore(), "default")
        scheduler.add_job(
            send_scheduled_email,
            trigger=CronTrigger(minute="*/59"),  # Every 59 minute
            id="send_scheduled_email",  # The `id` assigned to each job MUST be unique
            max_instances=1,
            replace_existing=True,
        )

        scheduler.add_job(
            delete_old_job_executions,
            trigger=CronTrigger(
                day_of_week="mon", hour="00", minute="00"
            ),  # Midnight on Monday, before start of the next work week.
            id="delete_old_job_executions",
            max_instances=1,
            replace_existing=True,
        )

        return scheduler