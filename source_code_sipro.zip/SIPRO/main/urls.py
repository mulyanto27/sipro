from django.urls import path

from . import views

app_name = "main"
urlpatterns = [
    path('', views.home, name="home"),
    path('dashboard', views.dashboard, name='dashboard'),
    path('login', views.login, name='login'),
    path('logout', views.logout, name='logout'),
    path('all-account', views.getAllUser, name='all-account'),
    path('create-account', views.createUser, name='create-account'),
    path('generate-report', views.generate_report, name='generate-report'),
    path('profile/<int:id>', views.get_profile, name='profile'),
    path('update-profile/<int:id>', views.update_profile, name='update-profile'),
    path('change-password/<int:id>', views.change_password, name='change-password'),
    path('update-account/<int:id>', views.updateUser, name='update-account'),
    path('delete-account/<int:id>', views.deleteUser, name='delete-account'),
    path('reset-password/<int:id>', views.resetPassword, name='reset-password'),
]