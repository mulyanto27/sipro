from datetime import datetime, timedelta, timezone
from django.db import models
from django.contrib.auth.models import User as auth_user


"""
Keterangan terkait role
- id    --> role_name
- 1     --> Superuser
- 2     --> Director
- 3     --> COO
- 4     --> Head of Business Delivery
- 5     --> PM
- 6     --> Admin GA
- 7     --> Admin Finance
- 8     --> Subkontraktor
"""
class Role(models.Model):
    role_name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return "{}-{}".format(self.id, self.role_name)


class User(models.Model):
    user = models.OneToOneField(auth_user,
                                on_delete=models.CASCADE,
                                primary_key=True)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)

    def __str__(self):
        return "{} - {}".format(self.user.email, self.role.role_name)

class Data_Subkontraktor(models.Model):
    vendor_name = models.CharField(max_length=50, unique=True)
    short_name = models.CharField(max_length=50, blank=True, null=True)
    address = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=20)
    email = models.CharField(max_length=50)
    bank_name = models.CharField(max_length=50)
    account_name = models.CharField(max_length=50)
    account_number = models.CharField(max_length=50)

    # approval_status: 0 --> Need Approval, 1 --> Approved, 2 --> Rejected
    approval_status = models.IntegerField()

    def __str__(self):
        return "{}".format(self.vendor_name)


class Subkontraktor(models.Model):
    user = models.OneToOneField(User,
                                on_delete=models.CASCADE,
                                primary_key=True)
    data_subkontraktor = models.OneToOneField(Data_Subkontraktor,
                                              on_delete=models.SET_NULL,
                                              blank=True,
                                              null=True)

class Project(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return "{}-{}".format(self.id, self.name)

class Area(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return "{}-{}".format(self.id, self.name)
"""
Keterangan terkait Category
- id    --> category_name
- 1     --> Sitebased
- 2     --> Workbased
- 3     --> Timebased
- 4     --> Rental Car
- 5     --> Rental Motorcycle
- 6     --> Rental Bike
- 7     --> Rental Genset
- 8     --> Materials
- 9     --> Others
"""
class Category(models.Model):
    category_name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return "{}-{}".format(self.id, self.category_name)


class Category_Data_Subkontraktor(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    data_subkontraktor = models.ForeignKey(Data_Subkontraktor,
                                           on_delete=models.CASCADE)

    def __str__(self):
        return "({}){} - {}".format(self.id, self.data_subkontraktor, self.category.category_name)

class Purchase_Request(models.Model):
    no_pr = models.CharField(max_length=50, unique=True)
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, blank=True, null=True)
    area = models.ForeignKey(Area, on_delete=models.SET_NULL, blank=True, null=True)
    pm = models.ForeignKey(User,
                           on_delete=models.SET_NULL,
                           blank=True,
                           null=True)
    data_subkontraktor = models.ForeignKey(Data_Subkontraktor,
                                           on_delete=models.PROTECT,
                                           blank=True,
                                           null=True)

    # status: 0 -> Requested, 1 -> Processed, 2 --> Cancelled
    status = models.IntegerField(default=0)
    date_created = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)

    # form_type: 1 -> Sitebased, 2 -> Workbased, 3 -> Timebased
    form_type = models.IntegerField()

    def __str__(self):
        return "{}-{}-{}".format(self.id, self.category.category_name, self.date_created)

class Worker_Email_Job(models.Model):
    subject = models.CharField(max_length=255)
    message = models.CharField(max_length=255)
    email_des = models.CharField(max_length=255)
    approval_status = models.CharField(max_length=20)

    def save(self, *args, **kwargs):
        if not self.pk:
            date_change = timedelta(days=3)
            if (self.approval_status=="PENDING"):
                date_change = timedelta(days=7)
            sent_at = datetime.now(tz=timezone.utc) + date_change
            job = Job(status = "TODO", email_job = self, sent_at = sent_at)
            super().save(*args, **kwargs)
            job.save()
        else:
            super().save(*args, **kwargs)

class Purchase_Order(models.Model):
    no_po = models.CharField(max_length=50, unique=True)
    pm = models.ForeignKey(User,
                           on_delete=models.SET_NULL,
                           blank=True,
                           null=True,
                           related_name="po_pm")
    hobd = models.ForeignKey(User,
                             on_delete=models.SET_NULL,
                             blank=True,
                             null=True,
                             related_name="hobd")
    pr = models.ForeignKey(Purchase_Request, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    data_subkontraktor = models.ForeignKey(Data_Subkontraktor,
                                           on_delete=models.SET_NULL,
                                           blank=True,
                                           null=True)
    date_created = models.DateField(auto_now=False, auto_now_add=False)

    ## status: 1 -> Waiting Approval PM; 2 -> Waiting Approval HOBD; 3 -> Active;
    ## 4 -> Closed; 5 -> Cancelled; 6 -> Rejected by PM; 7 -> Rejected by HOBD
    status = models.IntegerField()

    ## status_revision: 0 -> New; 1 -> Revision
    status_revision = models.IntegerField()
    feedback = models.CharField(max_length=255, blank=True, null=True)
    grand_total_price = models.DecimalField(default=0, 
        decimal_places=3,
        max_digits=20,
    )
    total_bill = models.DecimalField(default=0, decimal_places=3, max_digits=20)
    total_paid_off_bill = models.DecimalField(default=0, decimal_places=3, max_digits=20)
    outstanding_bill = models.DecimalField(default=0, decimal_places=3, max_digits=20)
    outstanding_grand_total = models.DecimalField(default=0, decimal_places=3,
                                                  max_digits=20)
    outstanding_po = models.DecimalField(default=0, decimal_places=3, max_digits=20)
    notes = models.TextField(blank=True, null=True)
    terms_of_payment = models.TextField(blank=True, null=True)
    cancellation_reason = models.CharField(max_length=255, blank=True, null=True)
    email_job = models.ForeignKey(Worker_Email_Job, 
                                    on_delete=models.CASCADE,
                                    blank=True,
                                    null=True)

    def __str__(self):
        return "{}-{}".format(self.no_po, self.category.category_name)

    def save(self, *args, **kwargs):
        if self.pr.form_type == 1:
            list_order = Item_Sitebased.objects.filter(sitebased__komponen__po__id = self.id)
        elif self.pr.form_type == 2:
            list_order = Item_Workbased.objects.filter(workbased__komponen__po__id = self.id)
        elif self.pr.form_type == 3:
            list_order = Timebased.objects.filter(komponen__po__id = self.id)
        temp_total_price = 0
        for order in list_order:
            temp_total_price += order.total_price
        self.grand_total_price = temp_total_price
        super().save(*args, **kwargs)

class Performa_Subkontraktor(models.Model):
    data_subkontraktor = models.ForeignKey(Data_Subkontraktor,
                                           on_delete=models.CASCADE)
    pm = models.ForeignKey(User,
                           on_delete=models.SET_NULL,
                           blank=True,
                           null=True)
    po = models.ForeignKey(Purchase_Order,
                           on_delete=models.CASCADE,
                           db_column="id_po")
    comment = models.CharField(max_length=255)

    def __str__(self):
        return "{}-{}".format(self.data_subkontraktor.vendor_name, self.po.no_po)


class Invoice(models.Model):
    no_invoice = models.CharField(max_length=50)
    prepared_by = models.ForeignKey(User,
                                    on_delete=models.SET_NULL,
                                    related_name="prepared_by",
                                    blank=True,
                                    null=True)
    pm = models.ForeignKey(User,
                           on_delete=models.SET_NULL,
                           blank=True,
                           null=True,
                           related_name="invoice_pm")
    director = models.ForeignKey(User,
                                 on_delete=models.SET_NULL,
                                 blank=True,
                                 null=True,
                                 related_name="director")
    coo = models.ForeignKey(User,
                            on_delete=models.SET_NULL,
                            blank=True,
                            null=True,
                            related_name="coo")
    data_subkontraktor = models.ForeignKey(Data_Subkontraktor,
                                           on_delete=models.SET_NULL,
                                           blank=True,
                                           null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    po = models.ForeignKey(Purchase_Order,
                           on_delete=models.CASCADE,
                           db_column="id_po")
    date = models.DateField(auto_now=False, auto_now_add=False)

    ## status: 0 -> Waiting Approval PM; 1 -> Waiting Approval COO; 2 -> Waiting Approval Director;
    ## 3 -> Rejected by PM; 4 -> Rejected by COO; 5 -> Rejected by Director; 6 -> Pending
    ## 7 -> Open, 8 --> Paid
    status = models.IntegerField()
    feedback = models.CharField(max_length=255, blank=True, null=True)
    supporting_document = models.FileField(upload_to='supporting_document/')
    notes = models.TextField(blank=True, null=True)
    grand_total_price = models.DecimalField(decimal_places=3, max_digits=20)
    invoice_quantity = models.DecimalField(decimal_places=1, max_digits=20)
    to_pay = models.DecimalField(decimal_places=3, max_digits=20)
    email_job = models.ForeignKey(Worker_Email_Job,
                                           on_delete=models.SET_NULL,
                                           blank=True,
                                           null=True)

    def __str__(self):
        return "{}-{}".format(self.no_invoice, self.category.category_name)


class Data_Pembayaran(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, db_column="id_invoice")
    proof_of_payment = models.FileField(upload_to='proof_of_payment/')
    payment_amount = models.DecimalField(decimal_places=3, max_digits=20)
    payment_date = models.DateTimeField(auto_now=False, auto_now_add=False)

    def __str__(self):
        return "Data Pembayaran ({}) dari Invoice ({})".format(self.id, self.invoice)
class Komponen(models.Model):
    pr = models.ForeignKey(Purchase_Request,
                           on_delete=models.CASCADE,
                           blank=True,
                           null=True)
    po = models.ForeignKey(Purchase_Order,
                           on_delete=models.CASCADE,
                           blank=True,
                           null=True,
                           db_column="id_po")
    invoice = models.ForeignKey(Invoice,
                                on_delete=models.CASCADE,
                                blank=True,
                                null=True, db_column="id_invoice")

    def __str__(self):
        return "Komponen ({})".format(self.id)


class Timebased(models.Model):
    komponen = models.OneToOneField(Komponen,
                                    on_delete=models.CASCADE,
                                    primary_key=True)
    item = models.CharField(max_length=255)
    item_detail = models.CharField(max_length=255)
    start_date = models.DateField(auto_now=False, auto_now_add=False)
    end_date = models.DateField(auto_now=False, auto_now_add=False)
    period = models.CharField(max_length=255)
    quantity = models.DecimalField(decimal_places=1, max_digits=20)
    unit_price = models.DecimalField(decimal_places=3,
                                     max_digits=20,
                                     default=0,
                                     blank=True,
                                     null=True)
    discount = models.DecimalField(decimal_places=1,
                                   max_digits=20,
                                   default=0,
                                   blank=True,
                                   null=True)
    total_price = models.DecimalField(decimal_places=3,
                                      max_digits=20,
                                      default=0,
                                      blank=True,
                                      null=True)
    invoice_comp_qty = models.DecimalField(decimal_places=2,
                                     max_digits=20,
                                     default=0,
                                     blank=True,
                                     null=True)
    total_bill = models.DecimalField(decimal_places=3,
                                      max_digits=20,
                                      default=0,
                                      blank=True,
                                      null=True)
    timebased_po = models.ForeignKey('Timebased',
                                    on_delete=models.CASCADE,
                                    blank=True,
                                    null=True, db_column="id_timebased")
    
    def __str__(self):
        return "{}".format(self.komponen)

    def save(self, *args, **kwargs):
        total_price = (float(self.unit_price) * float(self.quantity))
        discount = total_price * (float(self.discount) / 100)
        self.total_price = total_price - discount
        if self.komponen.po is not None:
            self.komponen.po.save()
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.komponen.po is not None:
            self.komponen.po.save()
        super().delete(*args, **kwargs)

class Sitebased(models.Model):
    komponen = models.OneToOneField(Komponen,
                                    on_delete=models.CASCADE,
                                    primary_key=True)
    site_id = models.CharField(max_length=255)
    site_name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)

    def __str__(self):
        return "{}".format(self.komponen)
class Item_Sitebased(models.Model):
    sitebased = models.ForeignKey(Sitebased, on_delete=models.CASCADE)
    sow = models.CharField(max_length=255)
    quantity = models.DecimalField(decimal_places=1, max_digits=20)
    unit_price = models.DecimalField(decimal_places=3,
                                     max_digits=20,
                                     default=0,
                                     blank=True,
                                     null=True)
    discount = models.DecimalField(decimal_places=1,
                                   max_digits=20,
                                   default=0,
                                   blank=True,
                                   null=True)
    total_price = models.DecimalField(decimal_places=3,
                                      max_digits=20,
                                      default=0,
                                      blank=True,
                                      null=True)
    invoice_comp_qty = models.DecimalField(decimal_places=2,
                                     max_digits=20,
                                     default=0,
                                     blank=True,
                                     null=True)
    total_bill = models.DecimalField(decimal_places=3,
                                      max_digits=20,
                                      default=0,
                                      blank=True,
                                      null=True)
    item_sb_po = models.ForeignKey('Item_Sitebased',
                                    on_delete=models.CASCADE,
                                    blank=True,
                                    null=True, db_column="id_item_sitebased")

    def __str__(self):
        return "Item Sitebased ({}) dari {}".format(self.id, self.sitebased)

    def save(self, *args, **kwargs):
        total_price = (float(self.unit_price) * float(self.quantity))
        discount = total_price * (float(self.discount) / 100)
        self.total_price = total_price - discount
        if self.sitebased.komponen.po is not None:
            self.sitebased.komponen.po.save()
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.sitebased.komponen.po is not None:
            self.sitebased.komponen.po.save()
        super().delete(*args, **kwargs)
class Workbased(models.Model):
    komponen = models.OneToOneField(Komponen,
                                    on_delete=models.CASCADE,
                                    primary_key=True)
    sow = models.CharField(max_length=255)
    description = models.CharField(max_length=255)

    def __str__(self):
        return "{}".format(self.komponen)
class Item_Workbased(models.Model):
    workbased = models.ForeignKey(Workbased, on_delete=models.CASCADE)
    site_id = models.CharField(max_length=255)
    site_name = models.CharField(max_length=255)
    quantity = models.DecimalField(decimal_places=1, max_digits=20)
    unit_price = models.DecimalField(decimal_places=3,
                                     max_digits=20,
                                     default=0,
                                     blank=True,
                                     null=True)
    discount = models.DecimalField(decimal_places=1,
                                   max_digits=20,
                                   default=0,
                                   blank=True,
                                   null=True)
    total_price = models.DecimalField(decimal_places=3,
                                      max_digits=20,
                                      default=0,
                                      blank=True,
                                      null=True)
    invoice_comp_qty = models.DecimalField(decimal_places=2,
                                     max_digits=20,
                                     default=0,
                                     blank=True,
                                     null=True)
    total_bill = models.DecimalField(decimal_places=3,
                                      max_digits=20,
                                      default=0,
                                      blank=True,
                                      null=True)
    item_wb_po = models.ForeignKey('Item_Workbased',
                                    on_delete=models.CASCADE,
                                    blank=True,
                                    null=True, db_column="id_item_workbased")

    def __str__(self):
        return "Item {} dari {}".format(self.id, self.workbased)
        
    def save(self, *args, **kwargs):
        total_price = (float(self.unit_price) * float(self.quantity))
        discount = total_price * (float(self.discount) / 100)
        self.total_price = total_price - discount
        if self.workbased.komponen.po is not None:
            self.workbased.komponen.po.save()
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.workbased.komponen.po is not None:
            self.workbased.komponen.po.save()
        super().delete(*args, **kwargs)

class Dokumen_Pembayaran_Subkontraktor(models.Model):
    po = models.ForeignKey(Purchase_Order,
                           on_delete=models.CASCADE,
                           db_column="id_po")
    date_uploaded = models.DateTimeField(auto_now=False, auto_now_add=False)
    attachment = models.FileField(upload_to='uploaded_documents/')
    notes = models.CharField(max_length=255, blank=True, null=True)
    status = models.IntegerField(default=0)

    def __str__(self):
        return "Dokumen ({}) untuk PO {}".format(self.id, self.po)

class Job(models.Model):
    status = models.CharField(max_length=20)
    email_job = models.ForeignKey(Worker_Email_Job, on_delete=models.CASCADE)
    sent_at = models.DateTimeField(auto_now=False, auto_now_add=False)