from datetime import date, time
from django.http.response import HttpResponseNotFound, HttpResponseForbidden
from main.models import Item_Sitebased, Komponen, Role, Subkontraktor, User, Category,\
    Category_Data_Subkontraktor, Purchase_Request, Purchase_Order,\
    Project, Area, Invoice, Data_Pembayaran, Data_Subkontraktor,\
    Timebased, Sitebased, Item_Workbased, Workbased
from django.shortcuts import redirect, render
from django.contrib.auth.models import User as auth_user
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.db.models import Count, F, Sum, Q
from django.db import IntegrityError
from django.http.response import FileResponse
from django.core.mail import send_mail
import string
import random
from io import BytesIO
import xlsxwriter

""" Views for dashboard """
def dashboard(request):
    if not (request.session['role_id'] == 8):
        # get summary per subcontractor
        subcont_category_count = Category_Data_Subkontraktor.objects\
            .values('category__category_name')\
            .annotate(subcont_count=Count('data_subkontraktor'),\
                name=F('category__category_name'))\
            .order_by('category__category_name')
        subcont_project_count = Purchase_Request.objects\
            .values('project__name')\
            .annotate(subcont_count=Count('data_subkontraktor',
                distinct=True), name=F('project__name'))\
            .order_by('project__name')
        subcont_area_count = Purchase_Request.objects\
            .values('area__name')\
            .annotate(subcont_count=Count('data_subkontraktor',\
                distinct=True), name=F('area__name'))\
            .order_by('area__name')
        all_subcont = Data_Subkontraktor.objects.all().count()
        
        # get summary per purchase request
        pr_category_count = Purchase_Request.objects\
            .values('category__category_name')\
            .annotate(pr_count=Count('id'),\
                name=F('category__category_name'))
        pr_project_count = Purchase_Request.objects\
            .values('project__name')\
            .annotate(pr_count=Count('id'), name=F('project__name'))
        pr_area_count = Purchase_Request.objects\
            .values('area__name')\
            .annotate(pr_count=Count('id'), name=F('area__name'))
        all_pr = Purchase_Request.objects.all().count()

        # get summary per purchase order
        po_category_count = Purchase_Order.objects\
            .values('category__category_name')\
            .annotate(po_count=Count('id'),\
                name=F('category__category_name'),\
                nominal=Sum('grand_total_price'))
        po_project_count = Purchase_Order.objects\
            .values('pr__project__name').annotate(po_count=Count('id'),\
                name=F('pr__project__name'),\
                nominal=Sum('grand_total_price'))
        po_area_count = Purchase_Order.objects\
            .values('pr__area__name').annotate(po_count=Count('id'),\
                name=F('pr__area__name'),\
                nominal=Sum('grand_total_price'))
        
        # get summary per invoice
        invoice_category_count = Invoice.objects\
            .values('category__category_name')\
            .annotate(invoice_count=Count('id'),\
                name=F('category__category_name'),\
                nominal=Sum('grand_total_price'))
        invoice_project_count = Invoice.objects\
            .values('po__pr__project__name')\
            .annotate(invoice_count=Count('id'),\
                name=F('po__pr__project__name'),\
                nominal=Sum('grand_total_price'))
        invoice_area_count = Invoice.objects\
            .values('po__pr__area__name')\
            .annotate(invoice_count=Count('id'),\
                name=F('po__pr__area__name'),\
                nominal=Sum('grand_total_price'))
        sum_invoice = Invoice.objects\
            .filter(status=7)\
            .aggregate(nominal=Sum('grand_total_price'))

        # get summary per data_pembayaran
        payment_category_count = Data_Pembayaran.objects\
            .values('invoice__category__category_name')\
            .annotate(payment_count=Count('id'), \
                name=F('invoice__category__category_name'), \
                nominal=Sum('payment_amount'))
        payment_project_count = Data_Pembayaran.objects\
            .values('invoice__po__pr__project__name')\
            .annotate(payment_count=Count('id'), \
                name=F('invoice__po__pr__project__name'), \
                nominal=Sum('payment_amount'))
        payment_area_count = Data_Pembayaran.objects\
            .values('invoice__po__pr__area__name')\
            .annotate(payment_count=Count('id'), \
                name=F('invoice__po__pr__area__name'), \
                nominal=Sum('payment_amount'))
        sum_payment = Data_Pembayaran.objects\
            .aggregate(nominal=Sum('payment_amount'))

        # summary of total and sum PO
        all_po = Purchase_Order.objects\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        rejected_po = Purchase_Order.objects\
            .filter(status__in=[6, 7])\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        requested_po = Purchase_Order.objects\
            .filter(status__in=[1, 2])\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        active_po = Purchase_Order.objects.filter(status=3)\
            .aggregate(count=Count('id'),
                    sum_total=Sum('grand_total_price'),
                    sum_outstanding=Sum('outstanding_grand_total'))
        cancelled_po = Purchase_Order.objects\
            .filter(status=5)\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        closed_po = Purchase_Order.objects.filter(status=4)\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        
        invoice_received = Invoice.objects\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        invoice_open = Invoice.objects\
            .filter(status=7)\
            .aggregate(count=Count('id'),
                    sum_total=Sum('grand_total_price'),
                    sum_outstanding=Sum('to_pay'))
        invoice_paid = Invoice.objects\
            .filter(status=8)\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        invoice_requested = Invoice.objects\
            .filter(status__in=[0, 1, 2])\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        invoice_rejected = Invoice.objects\
            .filter(status__in=[3, 4, 5])\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        pending_invoice = Invoice.objects\
            .filter(status=6)\
            .aggregate(count=Count('id'),
                    sum=Sum('grand_total_price'))
        results = {
            'subcont_category_count' : subcont_category_count,
            'subcont_project_count' : subcont_project_count,
            'subcont_area_count' : subcont_area_count,
            'pr_category_count' : pr_category_count,
            'pr_project_count' : pr_project_count,
            'pr_area_count' : pr_area_count,
            'po_category_count' : po_category_count,
            'po_project_count' : po_project_count,
            'po_area_count' : po_area_count,
            'invoice_category_count' : invoice_category_count,
            'invoice_project_count' : invoice_project_count,
            'invoice_area_count' : invoice_area_count,
            'payment_category_count' : payment_category_count,
            'payment_project_count' : payment_project_count,
            'payment_area_count' : payment_area_count,
            'all_subcont': all_subcont,
            'all_pr' : all_pr,
            'all_po' : all_po,
            'sum_invoice' : sum_invoice,
            'sum_payment' : sum_payment,
            'rejected_po' : rejected_po,
            'requested_po' : requested_po,
            'active_po' : active_po,
            'cancelled_po' : cancelled_po,
            'closed_po' : closed_po,
            'invoice_received' : invoice_received,
            'invoice_open' : invoice_open,
            'invoice_paid' : invoice_paid,
            'invoice_rejected' : invoice_rejected,
            'invoice_requested' : invoice_requested,
            'pending_invoice' : pending_invoice
        }
    else:
        return handle_403_page(request, HttpResponseForbidden)
    
    return render(request, "dashboard.html", results)

"""Views for forcing home to dashboard"""
def home(request):
    role_id = request.session['role_id']
    if role_id == 1:
            return redirect('main:all-account')
    if role_id == 8:
        return redirect('po:view_all_po')
    return redirect("main:dashboard")

def login_post(request):
    username = request.POST['username']
    password = request.POST['password']
    username = str(username)
    password = str(password)
    req_user = authenticate(username=username, password=password)
    if req_user is not None:
        auth_login(request, req_user)
        user = getUser(username)
        role = user.role.role_name
        request.session['first_name'] = user.user.first_name
        request.session['username'] = username
        request.session['user_id'] = user.user.id
        request.session['role'] = role
        request.session['role_id'] = user.role.id
        if (user.role.id == 1):
            return redirect('main:all-account')
        if (user.role.id == 8):
            return redirect('po:view_all_po')
        return redirect('main:dashboard')
    else:
        argument = {
            'message': "Username atau password tidak cocok"
        }
        return render(request, 'login.html', argument)


def login(request, message=None):
    if request.method == 'POST':
        return login_post(request)
    else:
        is_login = checkAuthentication(request)
        if not is_login:
            argument = {'message':message}
            return render(request, 'login.html', argument)
        else:
            return redirect("main:dashboard")

def checkAuthentication(request):
    try:
        request.session['username']
        return True
    except:
        return False


def logout(request, successChangePass=False):
    request.session.flush()
    request.session.clear_expired()
    auth_logout(request)
    if successChangePass:
        return login(request,"Your password has been updated, please re-login!")
    else:
        return login(request)

def getUser(username):
    try:
        a_user = auth_user.objects.get(username=username)
        user = User.objects.get(user=a_user.id)
        return user
    except:
        return None

def getAllUser(request, message=None):
    if request.session['role_id'] != 1 :
        return handle_403_page(request,HttpResponseForbidden)
    current_user_id = request.session['user_id']
    list_user = User.objects.filter(~Q(user__id=current_user_id)).order_by('user__id')
    argument = {'list_user': list_user, 'message': message}
    return render(request, 'home_account.html', argument)


def generateRandomPassword():
    letters = string.ascii_lowercase
    res = (''.join(random.choice(letters) for _ in range(10)))
    return res

def checkIfEmailAlreadyExist(email):
    list_user = auth_user.objects.all()
    for user in list_user:
        if (user.email.lower() == email.lower):
            return True
    return False

def createUser(request, message=None, is_error=False):
    if request.session['role_id'] != 1 :
        return handle_403_page(request,HttpResponseForbidden)
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        if (checkIfEmailAlreadyExist(email)):
            request.method = 'GET'
            return createUser(request, "Email sudah terdaftar dalam sistem",
                              True)
        role = request.POST['role']

        password = generateRandomPassword()
        try:
            a_user = auth_user.objects.create_user(email, email, password)
            a_user.first_name = name
            a_user.save()
        except:
            request.method = 'GET'
            return createUser(request, "Email sudah terdaftar dalam sistem",
                              True)

        role_obj = Role.objects.get(id=int(role))

        user = User(user=a_user, role=role_obj)
        user.save()

        try : 
            id_vendor = request.POST['vendor-data']
            subkontraktor = Subkontraktor(user = user, data_subkontraktor_id = id_vendor)
            subkontraktor.save()
        except IntegrityError:
            user.delete()
            a_user.delete()

            subkontraktor = Subkontraktor.objects.get(data_subkontraktor_id=id_vendor)
            related_username = subkontraktor.user.user.first_name
            message = "Failed to assign vendor, vendor {} already assigned to user {}".format(subkontraktor.data_subkontraktor.vendor_name, related_username)
            request.method = 'GET'
            return createUser(request, message, True)
        except:
            print("Subkontraktor role not selected")

        send_email_acc(email, password, "registrasikan")
        request.method = 'GET'
        return createUser(
            request, "Akun " + email + " dengan password " + password +
            " telah berhasil dibuat")
    else:
        roles = Role.objects.all().order_by('id')
        all_vendor = Data_Subkontraktor.objects.all().order_by('vendor_name')
        argument = {'roles': roles, 'message': message, 'is_error': is_error, 'all_vendor': all_vendor}
        return render(request, 'create_account.html', argument)

def updateUser(request, id, message=None, is_error=False):
    if request.session['role_id'] != 1 :
        return handle_403_page(request,HttpResponseForbidden)
    if request.method == 'POST':
        name = request.POST['name']
        role = request.POST['role']

        a_user = auth_user.objects.get(id=id)
        a_user.first_name = name
        a_user.save()

        role_obj = Role.objects.get(id=int(role))

        user = User.objects.get(user_id=a_user)
        user = User(user=a_user, role=role_obj)
        user.save()

        try : 
            id_vendor = request.POST['vendor-data']
            subkontraktor = Subkontraktor.objects.get(user=user)
            subkontraktor.data_subkontraktor_id = id_vendor 
            subkontraktor.save()
        except IntegrityError:
            subkontraktor = Subkontraktor.objects.get(data_subkontraktor_id=id_vendor)
            related_username = subkontraktor.user.user.first_name
            message = "Failed to assign vendor, vendor {} already assigned to user {}".format(subkontraktor.data_subkontraktor.vendor_name, related_username)
            request.method = 'GET'
            return updateUser(request, id, message, True)
        except:
            print("Subkontraktor role not selected")

        request.method = 'GET'
        return updateUser(request, id,
                          "Akun " + user.user.email + " berhasil diubah")
    else:
        roles = Role.objects.all().order_by('id')
        user = User.objects.get(user=id)
        all_vendor = Data_Subkontraktor.objects.all().order_by('vendor_name')
        argument = {
            'id': id,
            'roles': roles,
            'message': message,
            'def_user': user,
            'all_vendor': all_vendor,
            'is_error': is_error
        }
        try :
            vendor = Subkontraktor.objects.get(user = user)
            argument['vendor'] = vendor
        except:
            print("Failed to get vendor data")
        return render(request, 'update_account.html', argument)


def resetPassword(request, id):
    if request.session['role_id'] != 1 :
        return handle_403_page(request,HttpResponseForbidden)
    if request.method == 'POST':
        password = generateRandomPassword()
        a_user = auth_user.objects.get(id=id)
        a_user.set_password(password)
        a_user.save()

        request.method = 'GET'
        send_email_acc(a_user.email, password, " reset")
        return updateUser(
            request, id, "Password akun " + a_user.email +
            " berhasil direset dengan password: " + password)
    else:
        return handle_404_page(request, HttpResponseNotFound)


def deleteUser(request, id):
    if request.session['role_id'] != 1 :
        return handle_403_page(request,HttpResponseForbidden)
    try:
        a_user = auth_user.objects.get(id=id)
        user = User.objects.get(user_id=a_user)

        user.delete()
        a_user.delete()
        return getAllUser(request,
                          "Akun " + a_user.email + " berhasil dihapus")
    except:
        return handle_404_page(request, HttpResponseNotFound)

def get_profile(request, id, successUpdateProfile=False):
    user = User.objects.get(user_id = id)
    arg = {
        'user':user,
        'successUpdateProfile':successUpdateProfile,
    }
    return render(request, 'profile.html', arg)

def update_profile(request, id):
    user = User.objects.get(user_id = id)
    if request.method =='GET':
        arg = {
            'user':user
        }
        return render(request, 'edit_profile.html', arg)
    else:
        try:
            first_name = request.POST['name']
            request.session['first_name'] = first_name
            user.user.first_name = first_name
            user.user.save()
            request.method = 'GET'
            return get_profile(request,id,True)
        except:
            return handle_403_page(request, HttpResponseForbidden)

def change_password(request, id):
    user = User.objects.get(user_id = id)
    arg = {
        'user':user
    }
    if request.method =='GET':
        return render(request, 'change_password.html', arg)
    else:
        try:
            cur_pass = request.POST['cur_pass']
            is_password_match = user.user.check_password(cur_pass)
            if not is_password_match:
                arg['errOldPass'] = True
                return render(request, 'change_password.html', arg)
            new_pass = request.POST['new_pass']
            cof_pass = request.POST['cof_pass']
            if new_pass != cof_pass:
                arg['errMatchPass'] = True
                return render(request, 'change_password.html', arg)
            user.user.set_password(new_pass)
            user.user.save()
            request.method = 'GET'
            return logout(request,True)
        except:
            return handle_403_page(request, HttpResponseForbidden)

""" Views to Generate Summary Report """
def generate_report(request):
    #prepare the file
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()
    date_format = workbook.add_format({
        'num_format': 'dd/mm/yy'
        })
    merge_format = workbook.add_format({
        'bold': 1,
        'align': 'right',
        'valign': 'vcenter',
    })
    title_format = workbook.add_format({
        'bold':1
    })

    row = 0
    count = 1
    
    # get all PO
    list_po_timebased = Purchase_Order.objects.filter(pr__form_type=3)
    list_po_workbased = Purchase_Order.objects.filter(pr__form_type=2)
    list_po_sitebased = Purchase_Order.objects.filter(pr__form_type=1)
    
    # write title row
    data = [
        'No', 'PO Category','PO No.', 'PO Date', 'Supplier', 'Item/SOW',
        'Remarks PO', 'Project', 'Area', 'Site ID', 'Site Name',
        'Work Start', 'Work End', 'PO Final Amount', 
        'Invoice Received', 'Invoice Paid', 
        'Outstanding Invoice Payment', 'Outstanding PO Final',
        'PO Status'
    ]
    write_excel(worksheet, data, row, 0, title_format)
    row += 1

    # write all item PO Timebased
    for po in list_po_timebased:
        list_timebased = Timebased.objects\
            .filter(komponen__po=po)
        for timebased in list_timebased:
            data = [
                count, timebased.komponen.po.pr.category.category_name, 
                timebased.komponen.po.no_po,
                timebased.komponen.po.date_created,
                timebased.komponen.po.data_subkontraktor.vendor_name,
                timebased.item, timebased.item_detail, 
                timebased.komponen.po.pr.project.name,
                timebased.komponen.po.pr.area.name,
                "", "", timebased.start_date,
                timebased.end_date
            ]
            write_excel(worksheet, data, row, 0, date_format)
            row += 1
            count += 1
        
        status_PO = check_status_PO(po.status)
        data = [
            po.grand_total_price, po.total_bill,
            po.total_paid_off_bill, po.outstanding_bill,
            po.outstanding_grand_total, status_PO
        ]
        if (list_timebased.count() == 1):
            row -= 1
            write_excel(worksheet, data, row, 13, date_format)
            row += 1
        else:
            row += 1
            cell = "A{}:M{}".format(row, row)
            worksheet.merge_range(cell, 'Total', merge_format)
            row -= 1
            write_excel(worksheet, data, row, 13, date_format)
            row += 1

    # write all item PO Workbased
    for po in list_po_workbased:
        list_workbased = Item_Workbased.objects\
            .filter(workbased__komponen__po=po)
        for workbased in list_workbased:
            data = [
                count, workbased.workbased.komponen.po.pr.category.category_name, 
                workbased.workbased.komponen.po.no_po,
                workbased.workbased.komponen.po.date_created,
                workbased.workbased.komponen.po.data_subkontraktor.vendor_name,
                workbased.workbased.sow, workbased.workbased.description, 
                workbased.workbased.komponen.po.pr.project.name,
                workbased.workbased.komponen.po.pr.area.name,
                workbased.site_id, workbased.site_name, "", "",
            ]
            write_excel(worksheet, data, row, 0, date_format)
            row += 1
            count += 1

        status_PO = check_status_PO(po.status)
        data = [
            po.grand_total_price, po.total_bill,
            po.total_paid_off_bill, po.outstanding_bill,
            po.outstanding_grand_total, status_PO
        ]
        if (list_workbased.count() == 1):
            row -= 1
            write_excel(worksheet, data, row, 13, date_format)
            row += 1
        else:
            row += 1
            cell = "A{}:M{}".format(row, row)
            worksheet.merge_range(cell, 'Total', merge_format)
            row -= 1
            write_excel(worksheet, data, row, 13, date_format)
            row += 1
    
    # write all item PO Sitebased
    for po in list_po_sitebased:
        list_sitebased = Item_Sitebased.objects\
            .filter(sitebased__komponen__po=po)
        for sitebased in list_sitebased:
            data = [
                count, sitebased.sitebased.komponen.po.pr.category.category_name, 
                sitebased.sitebased.komponen.po.no_po,
                sitebased.sitebased.komponen.po.date_created,
                sitebased.sitebased.komponen.po.data_subkontraktor.vendor_name,
                sitebased.sow, sitebased.sitebased.description, 
                sitebased.sitebased.komponen.po.pr.project.name,
                sitebased.sitebased.komponen.po.pr.area.name,
                sitebased.sitebased.site_id, sitebased.sitebased.site_name, "", "",
            ]
            write_excel(worksheet, data, row, 0, date_format)
            row += 1
            count += 1
        
        status_PO = check_status_PO(po.status)
        data = [
            po.grand_total_price, po.total_bill,
            po.total_paid_off_bill, po.outstanding_bill,
            po.outstanding_grand_total, status_PO
        ]
        if (list_sitebased.count() == 1):
            row -= 1
            write_excel(worksheet, data, row, 13, date_format)
            row += 1
        else:
            row += 1
            cell = "A{}:M{}".format(row, row)
            worksheet.merge_range(cell, 'Total', merge_format)
            row -= 1
            write_excel(worksheet, data, row, 13, date_format)
            row += 1
    
    #close file
    workbook.close()
    output.seek(0)

    return FileResponse(output, as_attachment=True, filename='Summary_Report.xlsx')

def write_excel(worksheet, data, row, col, format):
    for each_data in data:
        if row == 0:
            worksheet.write(row, col, each_data, format)
        elif (col in [3, 11, 12]):
            worksheet.write(row, col, each_data, format)
        else:
            worksheet.write(row, col, each_data)
        col += 1

def check_status_PO(number):
    status = ""
    if number == 1:
        status = "Waiting Approval PM"
    elif number == 2:
        status = "Waiting Approval Head of Business Delivery"
    elif number == 3:
        status = "Active"
    elif number == 4:
        status = "Closed"
    elif number == 5:
        status = "Cancelled"
    elif number == 6:
        status = "Rejected by PM"
    elif number == 7:
        status = "Rejected by Head of Business Delivery"
    
    return status

def handle_404_page(request, exception):
    return render(request, '404.html')

def handle_403_page(request, exception):
    return render(request, '403.html')

def handle_400_page(request, exception):
    return render(request, '400.html')

def handle_500_page(request):
    return render(request, '500.html')

def send_email_acc(email_des, password, message):
    body = '''
    Selamat! Akun Anda telah berhasil di{} dalam sistem SIPRO, silahkan login dengan credential berikut:

    Email: {}
    Password: {}
    
    Silahkan ubah password anda setelah berhasil login kedalam sistem melalui menu profil.

    Best Regards,
    SIPRO CITIUS
    '''.format(message, email_des, password)

    send_mail(
        "[Account] SIPRO Account Credential",
        body,
        "citius.sipro@gmail.com", [email_des], False)