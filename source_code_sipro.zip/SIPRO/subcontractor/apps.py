from django.apps import AppConfig


class SubcontractorConfig(AppConfig):
    name = 'subcontractor'
