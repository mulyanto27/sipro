from django.http import request
from django.http.response import HttpResponse, \
    HttpResponseForbidden, HttpResponseNotFound
from django.shortcuts import redirect, render
from django.db import DatabaseError, IntegrityError
from django.contrib import messages
from main.views import handle_403_page, handle_404_page
from main.models import Data_Subkontraktor, Category_Data_Subkontraktor, \
    Purchase_Order, Performa_Subkontraktor, Category, Purchase_Request, User
from django.http.response import FileResponse
from io import BytesIO
import xlsxwriter

# Create your views here.

"""Views for getting all Data Subcontractor"""
def all_data_subcont(request):
    #get all data about each subcontractor and its categories
    list_data_subcont = Data_Subkontraktor.objects.all().order_by('vendor_name')
    list_category = Category_Data_Subkontraktor.objects.all()
    
    results = {
        'list_data_subcont': list_data_subcont,
        'list_category' : list_category,
    }
    
    return render(request, 'list_all_subcont.html', results)

"""Views for getting all Data Subcontractor which need approval"""
def need_approval_subcontlist(request):
    if request.session['role_id'] == 3: #check if role is COO
        #get all data about each subcontractor that needs approval and its categories
        list_data_subcont = Data_Subkontraktor.objects.order_by('vendor_name').filter(approval_status=0)
        list_category = Category_Data_Subkontraktor.objects.all()
        
        results = {
            'list_data_subcont': list_data_subcont,
            'list_category' : list_category,
        }
    
    else:
        return handle_403_page(request, HttpResponseForbidden)

    return render(request, 'subcont_need_approval.html', results)

"""Views for update status data subcontractor"""
def update_status(request, id):
    if request.session['role_id'] == 3: #check if role is COO
        data_subcont = Data_Subkontraktor.objects.get(id=id)

        #approve data subcont
        if request.POST.get("btn") == "Approve":
            data_subcont.approval_status = 1
        #reject data subcont
        elif request.POST.get("btn") == "Reject":
            data_subcont.approval_status = 2 
        
        data_subcont.save() #save udpates
        messages.info(request, 'Supplier\'s approval status has been changed.',
                    extra_tags='update_status')
    else:
        return handle_403_page(request, HttpResponseForbidden)

    return redirect('subcontractor:detail_data_subcont', id=data_subcont.id)


"""Views for detail Data Subcontractor"""
def detail_data_subcont(request, id):
    # get previous url
    prevUrl = checkUrl(request)

    #get all data about each subcontractor with its categories, performance, and po's
    data_subcont = Data_Subkontraktor.objects.get(id=id)
    subcont_category = Category_Data_Subkontraktor.objects.all().filter(
        data_subkontraktor_id=id)
    list_po_subcont = Purchase_Order.objects.all().filter(
        data_subkontraktor__id=id).order_by('date_created')
    performa_subcont = Performa_Subkontraktor.objects.all().filter(
        data_subkontraktor__id=id)
    
    #Calculate grand total for all PO in one subcontractor
    total = [0, 0, 0, 0, 0]
    for po in list_po_subcont:
        total[0] += po.grand_total_price
        total[1] += po.total_bill
        total[2] += po.total_paid_off_bill
        total[3] += po.outstanding_bill
        total[4] += po.outstanding_grand_total
    
    results = {
        'data_subcont': data_subcont,
        'subcont_category' : subcont_category,
        'list_po_subcont' : list_po_subcont,
        'performa_subcont' : performa_subcont,
        'total' : total,
        'prevUrl' : prevUrl,
    }    

    return render(request, 'detail_subcont.html', results)

"""Views for form create Data Subcontractor"""
def create_data_subcont(request):
    #retrieve all category
    all_categories = Category.objects.all()
    
    #dictionary to pass objects to templates
    results = {
        'categories': all_categories,
    }

    #add authorization for create only to Admin GA
    if request.session['role_id'] == 6:
        #saving new data subcont, retrieve all input
        if request.method == 'POST':
            try:
                #insert new subcontractor
                subcont_name = request.POST.get("subcont_name")
                short_name = request.POST.get("short_name")
                bank_name = request.POST.get("bank_name")
                account_number = request.POST.get("account_number")
                account_name = request.POST.get("account_name")
                email = request.POST.get("email")
                phone_number = request.POST.get("phone_number")
                address = request.POST.get("address")
                approval_status = request.POST.get("approval_status")
                new_subcont = Data_Subkontraktor(
                    vendor_name=subcont_name, short_name=short_name,
                    address=address, phone_number=phone_number,
                    bank_name=bank_name, email=email,
                    account_name=account_name, account_number=account_number,
                    approval_status=approval_status
                )
                new_subcont.save()

                #both insert and save category_data_subcontractor relationship
                categories = request.POST.getlist("category") #list all category related with subcontractor
                for category in categories:
                    new_category = Category.objects.get(category_name=category)
                    Category_Data_Subkontraktor.objects.create(category=new_category, data_subkontraktor=new_subcont) 
                
                #pass new data subcont to templates
                messages.info(request, 'New supplier has been created.',
                    extra_tags='create_success')
                results['new_subcont'] = new_subcont
                
                return redirect('subcontractor:detail_data_subcont',
                    id=new_subcont.id)
            
            except IntegrityError:
                #pass new data subcont to templates
                results['integrity_error'] = True
                results['new_subcont'] = new_subcont
    else:
        return handle_403_page(request, HttpResponseForbidden)
            
    return render(request, 'form_create_subcont.html', results)

""" Views for Delete Data Subcontractor """
def delete_data_subcont(request, id):
    #get subcont that will be deleted
    data_subcont = Data_Subkontraktor.objects.get(id=id)
    
    #add authorization for create only to Admin GA
    if request.session['role_id'] == 6:
        try:
            data_subcont.delete()
            messages.info(request, 'Delete supplier successful.',
                extra_tags='success')
        except IntegrityError:
            messages.info(request, 'Delete failed', extra_tags='failed')
    else:
        return handle_403_page(request, HttpResponseForbidden)
    
    return redirect('subcontractor:all_data_subcont')

""" Views for form edit Data Subcontractor """
def edit_data_subcont(request, id):
    #add authorization for create only to Admin GA
    if request.session['role_id'] == 6:
        #get data subcontractor and its related category with PR
        data_subcont = Data_Subkontraktor.objects.get(id=id)
        
        #check if a subcont already be requested in some PR
        approval_fixed = Purchase_Request.objects.filter(
            data_subkontraktor=data_subcont).exists()
        
        related_category_PR = Purchase_Request.objects.filter(
            data_subkontraktor=data_subcont).values_list(
            'category', flat=True)
        related_category_Subcont = Category_Data_Subkontraktor.objects.filter(
            data_subkontraktor=data_subcont).values_list(
            'category_id', flat=True)
        
        #get all category for form
        list_category = Category.objects.all()
        
        results = {
            'data_subcont' : data_subcont,
            'related_category_PR' : related_category_PR,
            'related_category_Subcont' : related_category_Subcont,
            'categories' : list_category,
            'approval_fixed' : approval_fixed,
        }

        if request.method == 'POST':
            try:
                # update data subcontractor from user input
                short_name = request.POST.get("short_name")
                bank_name = request.POST.get("bank_name")
                account_number = request.POST.get("account_number")
                account_name = request.POST.get("account_name")
                email = request.POST.get("email")
                phone_number = request.POST.get("phone_number")
                address = request.POST.get("address")
                approval_status = request.POST.get("approval_status")
                updated_subcont = Data_Subkontraktor.objects.filter(
                    id=id).update(
                    short_name=short_name, address=address,
                    phone_number=phone_number, bank_name=bank_name,
                    email=email, account_name=account_name, 
                    account_number=account_number, 
                    approval_status=approval_status
                )
                
                # list of user input for new category
                categories = request.POST.getlist("category")

                #list all category related with subcontractor
                subcont_category = Category_Data_Subkontraktor.objects.values_list(
                    'category', flat=True).filter(data_subkontraktor=data_subcont)
                current_category = Category.objects.filter(
                    id__in=set(subcont_category)).values_list(
                    'category_name', flat=True)
                
                # delete category that is unchecked by user
                for category in current_category:
                    if category not in categories:
                        Category_Data_Subkontraktor.objects.get(
                            category=Category.objects.get(category_name=category),
                            data_subkontraktor=data_subcont).delete()
                
                # insert new category from user input
                for category in categories:
                    if category not in current_category:
                        new_category = Category.objects.get(category_name=category)
                        Category_Data_Subkontraktor.objects.create(
                            category=new_category, data_subkontraktor=data_subcont)
                
                messages.info(request, 'Supplier data has been updated.',
                            extra_tags='update_success')
                
                return redirect('subcontractor:detail_data_subcont', id=data_subcont.id)
                    
            except IntegrityError:
                results['update_error'] = True
    else:
        return handle_403_page(request, HttpResponseForbidden)
    
    return render(request, 'form_edit_subcont.html', results)

'''Views for all Data Subcontractor based on Category'''
def dashboard_subcont(request, tab, name):
    if not (request.session['role_id'] == 8):
        results = {}
        if tab == 'category':
            #get all data about each subcontractor based on its categories
            subcont_per_category = Category_Data_Subkontraktor.objects.filter(
                category__category_name=name).values_list(
                'data_subkontraktor', flat=True)
            list_data_subcont = Data_Subkontraktor.objects.filter(
                id__in=set(subcont_per_category)).order_by('vendor_name')

            results['list_data_subcont'] = list_data_subcont
        
        elif tab == 'project':
            #get all data about each subcontractor based on its project name
            subcont_per_project = Purchase_Request.objects.filter(
                project__name=name).values_list(
                'data_subkontraktor', flat=True)
            list_data_subcont = Data_Subkontraktor.objects.filter(
                id__in=set(subcont_per_project)).order_by('vendor_name')
            
            results['list_data_subcont'] = list_data_subcont
        
        elif tab == 'area':
            #get all data about each subcontractor based on its area name
            subcont_per_area = Purchase_Request.objects.filter(
                area__name=name).values_list(
                'data_subkontraktor', flat=True)
            list_data_subcont = Data_Subkontraktor.objects.filter(
                id__in=set(subcont_per_area)).order_by('vendor_name')

            results['list_data_subcont'] = list_data_subcont
        else:
            return handle_404_page(request, HttpResponseNotFound)
        
        results['tab'] = tab.capitalize()
        results['name'] = name
    else:
        return handle_403_page(request, HttpResponseForbidden)
    
    return render(request, 'dashboard_subcont.html', results)

""" Views to Export All Data Subcontractor to Excel """
def export_supplier(request, mode):
    #prepare the file
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()

    row = 0
    col = 0

    #retrieve all data subcont
    if mode == 1: #to export all data subcont
        list_data_subkon = Data_Subkontraktor.objects.all()
    elif mode == 2:#to export all needs approval data subcont
        list_data_subkon = Data_Subkontraktor.objects.filter(approval_status=0)
    
    for row in range(len(list_data_subkon) + 1):
        #insert excel header as title of each data
        if (row == 0):
            data = [
                'Name','Short Name', 'Bank Name', 'Account Number',
                'Account Name', 'Phone', 'Email', 'Address', 'Category'
            ]

        #insert data to each column according to its header title
        else:
            data_subkon = list_data_subkon[row - 1]
            category = extract_category(data_subkon)
            data = [
                data_subkon.vendor_name, data_subkon.short_name,
                data_subkon.bank_name, data_subkon.account_number, 
                data_subkon.account_name, data_subkon.phone_number,
                data_subkon.email, data_subkon.address, category,
            ]

        #write data to file
        for each_data in data:
            worksheet.write(row, col, each_data)
            col += 1
        row += 1
        col = 0
    
    #close file
    workbook.close()
    output.seek(0)

    return FileResponse(output, as_attachment=True, filename='Data_Supplier.xlsx')

""" Function to Extract Category for Subcontractor """
def extract_category(data_subkon):
    #get all category for data_subkon
    categories = Category_Data_Subkontraktor.objects.filter(
        data_subkontraktor=data_subkon)

    #get each category name from categories
    list_category = [c.category.category_name for c in categories]

    #formatting category from list_category become string
    category = ""
    for category_name in list_category:
        category += category_name + ', '
    category = category[:-2]
    
    return category

def get_all_feedback(request, id_subkon):
    feedbacks = Performa_Subkontraktor.objects.filter(data_subkontraktor_id=id_subkon)
    arg = {
        'feedbacks' : feedbacks,
        'id_subkon' : id_subkon
    }
    return render(request, 'feedbacks_subcont.html', arg)

"""Function to check previous URL"""
def checkUrl(request):
    prevUrl = ""
    url = request.META.get('HTTP_REFERER')
    if "project" in url:
        prevUrl = url
    elif "category" in url:
        prevUrl = url
    elif "area" in url:
        prevUrl = url
    elif "needs-approval" in url:
        prevUrl = url
    elif (any(char.isdigit() for char in url) and request.session['role_id'] == 3):
        prevUrl = "/supplier/needs-approval"
    else:
        prevUrl = "/supplier"
    return prevUrl