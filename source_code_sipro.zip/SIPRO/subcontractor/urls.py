from django.urls import path

from . import views

app_name = "subcontractor"
urlpatterns = [
    path('', views.all_data_subcont, name='all_data_subcont'),
    path('needs-approval/', views.need_approval_subcontlist, name='needs_approval_subcontlist'),
    path('create/', views.create_data_subcont, name='create_data_subcont'),
    path('<int:id>/', views.detail_data_subcont, name='detail_data_subcont'),
    path('excel-supplier/<int:mode>', views.export_supplier, name='excel-supplier'),
    path('feedbacks/<int:id_subkon>', views.get_all_feedback, name='get_all_feedback'),
    path('delete/<int:id>', views.delete_data_subcont, name='delete_data_subcont'),
    path('edit/<int:id>', views.edit_data_subcont, name='edit_data_subcont'),
    path('update_status/<int:id>', views.update_status, name='update_status'),
    path('<str:tab>/<str:name>', views.dashboard_subcont, name='dashboard_subcont'),
]